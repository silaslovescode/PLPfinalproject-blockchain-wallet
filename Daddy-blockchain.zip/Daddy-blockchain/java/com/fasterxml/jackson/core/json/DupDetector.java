package com.fasterxml.jackson.core.json;

import com.fasterxml.jackson.core.JsonParseException;
import java.util.HashSet;

/* loaded from: classes.dex */
public final class DupDetector {
    protected String _firstName;
    protected String _secondName;
    protected HashSet<String> _seen;
    protected final Object _source;

    private DupDetector(Object src) {
        this._source = src;
    }

    public final DupDetector child() {
        return new DupDetector(this._source);
    }

    public final void reset() {
        this._firstName = null;
        this._secondName = null;
        this._seen = null;
    }

    public final Object getSource() {
        return this._source;
    }

    public final boolean isDup(String name) throws JsonParseException {
        if (this._firstName == null) {
            this._firstName = name;
            return false;
        } else if (name.equals(this._firstName)) {
            return true;
        } else {
            if (this._secondName == null) {
                this._secondName = name;
                return false;
            } else if (name.equals(this._secondName)) {
                return true;
            } else {
                if (this._seen == null) {
                    this._seen = new HashSet<>(16);
                    this._seen.add(this._firstName);
                    this._seen.add(this._secondName);
                }
                return !this._seen.add(name);
            }
        }
    }
}
