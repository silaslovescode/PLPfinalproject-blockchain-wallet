package com.fasterxml.jackson.annotation;

import java.io.Serializable;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Locale;
import java.util.TimeZone;

@Target({ElementType.ANNOTATION_TYPE, ElementType.FIELD, ElementType.METHOD, ElementType.PARAMETER, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
/* loaded from: classes.dex */
public @interface JsonFormat {

    /* loaded from: classes.dex */
    public enum Shape {
        ANY,
        SCALAR,
        ARRAY,
        OBJECT,
        NUMBER,
        NUMBER_FLOAT,
        NUMBER_INT,
        STRING,
        BOOLEAN
    }

    /* loaded from: classes.dex */
    public static class Features {
        private static final Features EMPTY = new Features();
        private final int _enabled = 0;
        private final int _disabled = 0;

        private Features() {
        }

        public static Features empty() {
            return EMPTY;
        }

        public final int hashCode() {
            return this._disabled + this._enabled;
        }

        public final boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (o != null && o.getClass() == getClass()) {
                Features other = (Features) o;
                return other._enabled == this._enabled && other._disabled == this._disabled;
            }
            return false;
        }
    }

    /* loaded from: classes.dex */
    public static class Value implements Serializable {
        private static final Value EMPTY = new Value();
        private static final long serialVersionUID = 1;
        private final Features _features;
        private final Locale _locale;
        private final String _pattern;
        private final Shape _shape;
        private transient TimeZone _timezone;
        private final String _timezoneStr;

        public Value() {
            this("", Shape.ANY, "", "", Features.empty());
        }

        private Value(String p, Shape sh, String localeStr, String tzStr, Features f) {
            this(p, sh, (localeStr.length() == 0 || "##default".equals(localeStr)) ? null : new Locale(localeStr), (tzStr.length() == 0 || "##default".equals(tzStr)) ? null : tzStr, f);
        }

        private Value(String p, Shape sh, Locale l, String tzStr, Features f) {
            this._pattern = p;
            this._shape = sh == null ? Shape.ANY : sh;
            this._locale = l;
            this._timezone = null;
            this._timezoneStr = tzStr;
            this._features = f == null ? Features.empty() : f;
        }

        public static final Value empty() {
            return EMPTY;
        }

        public final String toString() {
            return String.format("[pattern=%s,shape=%s,locale=%s,timezone=%s]", this._pattern, this._shape, this._locale, this._timezoneStr);
        }

        public final int hashCode() {
            int hash = this._timezoneStr == null ? 1 : this._timezoneStr.hashCode();
            if (this._pattern != null) {
                hash ^= this._pattern.hashCode();
            }
            int hash2 = hash + this._shape.hashCode();
            if (this._locale != null) {
                hash2 ^= this._locale.hashCode();
            }
            return this._features.hashCode() + hash2;
        }

        public final boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (o != null && o.getClass() == getClass()) {
                Value other = (Value) o;
                if (this._shape != other._shape || !this._features.equals(other._features)) {
                    return false;
                }
                return _equal(this._timezoneStr, other._timezoneStr) && _equal(this._pattern, other._pattern) && _equal(this._timezone, other._timezone) && _equal(this._locale, other._locale);
            }
            return false;
        }

        private static <T> boolean _equal(T value1, T value2) {
            if (value1 == null) {
                return value2 == null;
            } else if (value2 == null) {
                return false;
            } else {
                return value1.equals(value2);
            }
        }
    }
}
