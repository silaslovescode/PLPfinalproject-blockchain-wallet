package com.aurelhubert.ahbottomnavigation.notification;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class AHNotification implements Parcelable {
    public static final Parcelable.Creator<AHNotification> CREATOR = new Parcelable.Creator<AHNotification>() { // from class: com.aurelhubert.ahbottomnavigation.notification.AHNotification.1
        @Override // android.os.Parcelable.Creator
        public final /* bridge */ /* synthetic */ AHNotification[] newArray(int i) {
            return new AHNotification[i];
        }

        @Override // android.os.Parcelable.Creator
        public final /* bridge */ /* synthetic */ AHNotification createFromParcel(Parcel parcel) {
            return new AHNotification(parcel, (byte) 0);
        }
    };
    public int backgroundColor;
    public String text;
    public int textColor;

    /* loaded from: classes.dex */
    public static class Builder {
        int backgroundColor;
        String text;
        int textColor;
    }

    /* synthetic */ AHNotification(Parcel x0, byte b) {
        this(x0);
    }

    public AHNotification() {
    }

    private AHNotification(Parcel in) {
        this.text = in.readString();
        this.textColor = in.readInt();
        this.backgroundColor = in.readInt();
    }

    public static AHNotification justText(String text) {
        Builder builder = new Builder();
        builder.text = text;
        AHNotification aHNotification = new AHNotification();
        aHNotification.text = builder.text;
        aHNotification.textColor = builder.textColor;
        aHNotification.backgroundColor = builder.backgroundColor;
        return aHNotification;
    }

    public static List<AHNotification> generateEmptyList$22f3aa59() {
        List<AHNotification> notificationList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            notificationList.add(new AHNotification());
        }
        return notificationList;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.text);
        dest.writeInt(this.textColor);
        dest.writeInt(this.backgroundColor);
    }
}
