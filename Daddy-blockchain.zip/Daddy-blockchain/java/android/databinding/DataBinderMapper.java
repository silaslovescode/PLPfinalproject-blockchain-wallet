package android.databinding;

/* loaded from: classes.dex */
final class DataBinderMapper {
    static final int TARGET_MIN_SDK = 14;
}
