package android.support.p000v4.p001os;

import android.annotation.TargetApi;
import android.os.Parcel;
import android.os.Parcelable;

@TargetApi(13)
/* renamed from: android.support.v4.os.ParcelableCompatCreatorHoneycombMR2 */
/* loaded from: classes.dex */
final class ParcelableCompatHoneycombMR2<T> implements Parcelable.ClassLoaderCreator<T> {
    private final ParcelableCompatCreatorCallbacks<T> mCallbacks;

    public ParcelableCompatHoneycombMR2(ParcelableCompatCreatorCallbacks<T> callbacks) {
        this.mCallbacks = callbacks;
    }

    @Override // android.os.Parcelable.Creator
    public final T createFromParcel(Parcel in) {
        return this.mCallbacks.mo94createFromParcel(in, null);
    }

    @Override // android.os.Parcelable.ClassLoaderCreator
    public final T createFromParcel(Parcel in, ClassLoader loader) {
        return this.mCallbacks.mo94createFromParcel(in, loader);
    }

    @Override // android.os.Parcelable.Creator
    public final T[] newArray(int size) {
        return this.mCallbacks.mo95newArray(size);
    }
}
