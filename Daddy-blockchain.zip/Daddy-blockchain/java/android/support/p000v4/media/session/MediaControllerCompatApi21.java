package android.support.p000v4.media.session;

import android.annotation.TargetApi;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Bundle;
import java.util.List;

@TargetApi(21)
/* renamed from: android.support.v4.media.session.MediaControllerCompatApi21 */
/* loaded from: classes.dex */
public final class MediaControllerCompatApi21 {

    /* renamed from: android.support.v4.media.session.MediaControllerCompatApi21$Callback */
    /* loaded from: classes.dex */
    public interface Callback {
        void onAudioInfoChanged(int i, int i2, int i3, int i4, int i5);

        void onMetadataChanged(Object obj);

        void onPlaybackStateChanged(Object obj);

        void onQueueChanged(List<?> list);

        void onSessionEvent$5dc9c75();
    }

    public static Object fromToken(Context context, Object sessionToken) {
        return new MediaController(context, (MediaSession.Token) sessionToken);
    }

    /* renamed from: android.support.v4.media.session.MediaControllerCompatApi21$CallbackProxy */
    /* loaded from: classes.dex */
    static class CallbackProxy<T extends Callback> extends MediaController.Callback {
        protected final T mCallback;

        public CallbackProxy(T callback) {
            this.mCallback = callback;
        }

        @Override // android.media.session.MediaController.Callback
        public final void onSessionDestroyed() {
        }

        @Override // android.media.session.MediaController.Callback
        public final void onSessionEvent(String event, Bundle extras) {
            this.mCallback.onSessionEvent$5dc9c75();
        }

        @Override // android.media.session.MediaController.Callback
        public final void onPlaybackStateChanged(PlaybackState state) {
            this.mCallback.onPlaybackStateChanged(state);
        }

        @Override // android.media.session.MediaController.Callback
        public final void onMetadataChanged(MediaMetadata metadata) {
            this.mCallback.onMetadataChanged(metadata);
        }

        @Override // android.media.session.MediaController.Callback
        public final void onQueueChanged(List<MediaSession.QueueItem> queue) {
            this.mCallback.onQueueChanged(queue);
        }

        @Override // android.media.session.MediaController.Callback
        public final void onQueueTitleChanged(CharSequence title) {
        }

        @Override // android.media.session.MediaController.Callback
        public final void onExtrasChanged(Bundle extras) {
        }

        @Override // android.media.session.MediaController.Callback
        public final void onAudioInfoChanged(MediaController.PlaybackInfo info2) {
            int i;
            T t = this.mCallback;
            int playbackType = info2.getPlaybackType();
            AudioAttributes audioAttributes = info2.getAudioAttributes();
            if ((audioAttributes.getFlags() & 1) == 1) {
                i = 7;
            } else if ((audioAttributes.getFlags() & 4) == 4) {
                i = 6;
            } else {
                switch (audioAttributes.getUsage()) {
                    case 1:
                    case 11:
                    case 12:
                    case 14:
                        i = 3;
                        break;
                    case 2:
                        i = 0;
                        break;
                    case 3:
                        i = 8;
                        break;
                    case 4:
                        i = 4;
                        break;
                    case 5:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                        i = 5;
                        break;
                    case 6:
                        i = 2;
                        break;
                    case 13:
                        i = 1;
                        break;
                    default:
                        i = 3;
                        break;
                }
            }
            t.onAudioInfoChanged(playbackType, i, info2.getVolumeControl(), info2.getMaxVolume(), info2.getCurrentVolume());
        }
    }
}
