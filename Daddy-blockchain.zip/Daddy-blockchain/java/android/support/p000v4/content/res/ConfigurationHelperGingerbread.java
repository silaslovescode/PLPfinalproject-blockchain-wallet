package android.support.p000v4.content.res;

import android.annotation.TargetApi;
import android.content.res.Resources;
import android.util.DisplayMetrics;

@TargetApi(9)
/* renamed from: android.support.v4.content.res.ConfigurationHelperGingerbread */
/* loaded from: classes.dex */
final class ConfigurationHelperGingerbread {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static int getScreenHeightDp(Resources resources) {
        DisplayMetrics metrics = resources.getDisplayMetrics();
        return (int) (metrics.heightPixels / metrics.density);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int getScreenWidthDp(Resources resources) {
        DisplayMetrics metrics = resources.getDisplayMetrics();
        return (int) (metrics.widthPixels / metrics.density);
    }
}
