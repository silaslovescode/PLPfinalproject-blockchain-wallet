package android.support.p000v4.content.res;

import android.content.res.Resources;
import android.os.Build;

/* renamed from: android.support.v4.content.res.ConfigurationHelper */
/* loaded from: classes.dex */
public final class ConfigurationHelper {
    private static final ConfigurationHelperImpl IMPL;

    /* renamed from: android.support.v4.content.res.ConfigurationHelper$ConfigurationHelperImpl */
    /* loaded from: classes.dex */
    private interface ConfigurationHelperImpl {
        int getScreenHeightDp(Resources resources);

        int getScreenWidthDp(Resources resources);

        int getSmallestScreenWidthDp(Resources resources);
    }

    static {
        int sdk = Build.VERSION.SDK_INT;
        if (sdk >= 17) {
            IMPL = new JellybeanMr1Impl();
        } else if (sdk >= 13) {
            IMPL = new HoneycombMr2Impl();
        } else {
            IMPL = new GingerbreadImpl();
        }
    }

    /* renamed from: android.support.v4.content.res.ConfigurationHelper$GingerbreadImpl */
    /* loaded from: classes.dex */
    private static class GingerbreadImpl implements ConfigurationHelperImpl {
        GingerbreadImpl() {
        }

        @Override // android.support.p000v4.content.res.ConfigurationHelper.ConfigurationHelperImpl
        public int getScreenHeightDp(Resources resources) {
            return ConfigurationHelperGingerbread.getScreenHeightDp(resources);
        }

        @Override // android.support.p000v4.content.res.ConfigurationHelper.ConfigurationHelperImpl
        public int getScreenWidthDp(Resources resources) {
            return ConfigurationHelperGingerbread.getScreenWidthDp(resources);
        }

        @Override // android.support.p000v4.content.res.ConfigurationHelper.ConfigurationHelperImpl
        public int getSmallestScreenWidthDp(Resources resources) {
            return Math.min(ConfigurationHelperGingerbread.getScreenWidthDp(resources), ConfigurationHelperGingerbread.getScreenHeightDp(resources));
        }
    }

    /* renamed from: android.support.v4.content.res.ConfigurationHelper$HoneycombMr2Impl */
    /* loaded from: classes.dex */
    private static class HoneycombMr2Impl extends GingerbreadImpl {
        HoneycombMr2Impl() {
        }

        @Override // android.support.p000v4.content.res.ConfigurationHelper.GingerbreadImpl, android.support.p000v4.content.res.ConfigurationHelper.ConfigurationHelperImpl
        public final int getScreenHeightDp(Resources resources) {
            return resources.getConfiguration().screenHeightDp;
        }

        @Override // android.support.p000v4.content.res.ConfigurationHelper.GingerbreadImpl, android.support.p000v4.content.res.ConfigurationHelper.ConfigurationHelperImpl
        public final int getScreenWidthDp(Resources resources) {
            return resources.getConfiguration().screenWidthDp;
        }

        @Override // android.support.p000v4.content.res.ConfigurationHelper.GingerbreadImpl, android.support.p000v4.content.res.ConfigurationHelper.ConfigurationHelperImpl
        public final int getSmallestScreenWidthDp(Resources resources) {
            return resources.getConfiguration().smallestScreenWidthDp;
        }
    }

    /* renamed from: android.support.v4.content.res.ConfigurationHelper$JellybeanMr1Impl */
    /* loaded from: classes.dex */
    private static class JellybeanMr1Impl extends HoneycombMr2Impl {
        JellybeanMr1Impl() {
        }
    }

    public static int getScreenHeightDp(Resources resources) {
        return IMPL.getScreenHeightDp(resources);
    }

    public static int getScreenWidthDp(Resources resources) {
        return IMPL.getScreenWidthDp(resources);
    }

    public static int getSmallestScreenWidthDp(Resources resources) {
        return IMPL.getSmallestScreenWidthDp(resources);
    }
}
