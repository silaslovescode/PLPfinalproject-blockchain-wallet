package android.support.p000v4.content;

import android.support.p000v4.util.DebugUtils;

/* renamed from: android.support.v4.content.Loader */
/* loaded from: classes.dex */
public final class Loader<D> {
    public boolean mAbandoned;
    public boolean mContentChanged;
    public int mId;
    public OnLoadCompleteListener<D> mListener;
    public OnLoadCanceledListener<D> mOnLoadCanceledListener;
    public boolean mProcessingChange;
    public boolean mReset;
    public boolean mStarted;

    /* renamed from: android.support.v4.content.Loader$OnLoadCanceledListener */
    /* loaded from: classes.dex */
    public interface OnLoadCanceledListener<D> {
    }

    /* renamed from: android.support.v4.content.Loader$OnLoadCompleteListener */
    /* loaded from: classes.dex */
    public interface OnLoadCompleteListener<D> {
    }

    public final void unregisterListener(OnLoadCompleteListener<D> listener) {
        if (this.mListener == null) {
            throw new IllegalStateException("No listener register");
        }
        if (this.mListener != listener) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        }
        this.mListener = null;
    }

    public final void unregisterOnLoadCanceledListener(OnLoadCanceledListener<D> listener) {
        if (this.mOnLoadCanceledListener == null) {
            throw new IllegalStateException("No listener register");
        }
        if (this.mOnLoadCanceledListener != listener) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        }
        this.mOnLoadCanceledListener = null;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(64);
        DebugUtils.buildShortClassTag(this, sb);
        sb.append(" id=");
        sb.append(this.mId);
        sb.append("}");
        return sb.toString();
    }
}
