package android.support.p000v4.content;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Build;

/* renamed from: android.support.v4.content.IntentCompat */
/* loaded from: classes.dex */
public final class IntentCompat {
    private static final IntentCompatImpl IMPL;

    /* renamed from: android.support.v4.content.IntentCompat$IntentCompatImpl */
    /* loaded from: classes.dex */
    interface IntentCompatImpl {
        Intent makeMainActivity(ComponentName componentName);
    }

    /* renamed from: android.support.v4.content.IntentCompat$IntentCompatImplBase */
    /* loaded from: classes.dex */
    static class IntentCompatImplBase implements IntentCompatImpl {
        IntentCompatImplBase() {
        }

        @Override // android.support.p000v4.content.IntentCompat.IntentCompatImpl
        public Intent makeMainActivity(ComponentName componentName) {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.setComponent(componentName);
            intent.addCategory("android.intent.category.LAUNCHER");
            return intent;
        }
    }

    /* renamed from: android.support.v4.content.IntentCompat$IntentCompatImplHC */
    /* loaded from: classes.dex */
    static class IntentCompatImplHC extends IntentCompatImplBase {
        IntentCompatImplHC() {
        }

        @Override // android.support.p000v4.content.IntentCompat.IntentCompatImplBase, android.support.p000v4.content.IntentCompat.IntentCompatImpl
        public final Intent makeMainActivity(ComponentName componentName) {
            return Intent.makeMainActivity(componentName);
        }
    }

    /* renamed from: android.support.v4.content.IntentCompat$IntentCompatImplIcsMr1 */
    /* loaded from: classes.dex */
    static class IntentCompatImplIcsMr1 extends IntentCompatImplHC {
        IntentCompatImplIcsMr1() {
        }
    }

    static {
        int version = Build.VERSION.SDK_INT;
        if (version >= 15) {
            IMPL = new IntentCompatImplIcsMr1();
        } else if (version >= 11) {
            IMPL = new IntentCompatImplHC();
        } else {
            IMPL = new IntentCompatImplBase();
        }
    }

    public static Intent makeMainActivity(ComponentName mainActivity) {
        return IMPL.makeMainActivity(mainActivity);
    }
}
