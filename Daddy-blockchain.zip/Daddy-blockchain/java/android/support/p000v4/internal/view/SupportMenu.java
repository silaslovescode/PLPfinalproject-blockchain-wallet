package android.support.p000v4.internal.view;

import android.view.Menu;

/* renamed from: android.support.v4.internal.view.SupportMenu */
/* loaded from: classes.dex */
public interface SupportMenu extends Menu {
}
