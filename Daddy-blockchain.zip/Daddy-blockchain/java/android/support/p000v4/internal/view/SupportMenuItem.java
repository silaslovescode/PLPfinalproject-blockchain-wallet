package android.support.p000v4.internal.view;

import android.support.p000v4.view.ActionProvider;
import android.support.p000v4.view.MenuItemCompat;
import android.view.MenuItem;
import android.view.View;

/* renamed from: android.support.v4.internal.view.SupportMenuItem */
/* loaded from: classes.dex */
public interface SupportMenuItem extends MenuItem {
    @Override // android.view.MenuItem
    boolean collapseActionView();

    @Override // android.view.MenuItem
    boolean expandActionView();

    @Override // android.view.MenuItem
    View getActionView();

    ActionProvider getSupportActionProvider();

    @Override // android.view.MenuItem
    boolean isActionViewExpanded();

    @Override // android.view.MenuItem
    /* renamed from: setActionView */
    MenuItem mo68setActionView(int i);

    @Override // android.view.MenuItem
    /* renamed from: setActionView */
    MenuItem mo69setActionView(View view);

    @Override // android.view.MenuItem
    void setShowAsAction(int i);

    @Override // android.view.MenuItem
    /* renamed from: setShowAsActionFlags */
    MenuItem mo70setShowAsActionFlags(int i);

    SupportMenuItem setSupportActionProvider(ActionProvider actionProvider);

    SupportMenuItem setSupportOnActionExpandListener(MenuItemCompat.OnActionExpandListener onActionExpandListener);
}
