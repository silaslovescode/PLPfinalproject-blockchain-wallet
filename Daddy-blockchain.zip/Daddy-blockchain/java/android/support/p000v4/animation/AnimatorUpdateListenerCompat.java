package android.support.p000v4.animation;

/* renamed from: android.support.v4.animation.AnimatorUpdateListenerCompat */
/* loaded from: classes.dex */
public interface AnimatorUpdateListenerCompat {
    void onAnimationUpdate(ValueAnimatorCompat valueAnimatorCompat);
}
