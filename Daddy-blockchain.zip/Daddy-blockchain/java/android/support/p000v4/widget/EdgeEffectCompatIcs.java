package android.support.p000v4.widget;

import android.annotation.TargetApi;
import android.widget.EdgeEffect;

@TargetApi(14)
/* renamed from: android.support.v4.widget.EdgeEffectCompatIcs */
/* loaded from: classes.dex */
final class EdgeEffectCompatIcs {
    public static boolean onPull(Object edgeEffect, float deltaDistance) {
        ((EdgeEffect) edgeEffect).onPull(deltaDistance);
        return true;
    }
}
