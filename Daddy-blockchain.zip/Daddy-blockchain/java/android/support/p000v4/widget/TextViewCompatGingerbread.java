package android.support.p000v4.widget;

import android.annotation.TargetApi;
import android.widget.TextView;
import java.lang.reflect.Field;

@TargetApi(9)
/* renamed from: android.support.v4.widget.TextViewCompatGingerbread */
/* loaded from: classes.dex */
final class TextViewCompatGingerbread {
    static Field sMaxModeField;
    static boolean sMaxModeFieldFetched;
    static Field sMaximumField;
    static boolean sMaximumFieldFetched;

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Field retrieveField(String fieldName) {
        Field field = null;
        try {
            field = TextView.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            return field;
        } catch (NoSuchFieldException e) {
            new StringBuilder("Could not retrieve ").append(fieldName).append(" field.");
            return field;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static int retrieveIntFromField(Field field, TextView textView) {
        try {
            return field.getInt(textView);
        } catch (IllegalAccessException e) {
            new StringBuilder("Could not retrieve value of ").append(field.getName()).append(" field.");
            return -1;
        }
    }
}
