package android.support.p000v4.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.widget.SearchView;

@TargetApi(14)
/* renamed from: android.support.v4.widget.SearchViewCompatIcs */
/* loaded from: classes.dex */
final class SearchViewCompatIcs {

    /* renamed from: android.support.v4.widget.SearchViewCompatIcs$MySearchView */
    /* loaded from: classes.dex */
    public static class MySearchView extends SearchView {
        public MySearchView(Context context) {
            super(context);
        }

        @Override // android.widget.SearchView, android.view.CollapsibleActionView
        public void onActionViewCollapsed() {
            setQuery("", false);
            super.onActionViewCollapsed();
        }
    }
}
