package android.support.p000v4.widget;

import android.content.Context;
import android.os.Build;
import android.view.animation.Interpolator;
import android.widget.OverScroller;

/* renamed from: android.support.v4.widget.ScrollerCompat */
/* loaded from: classes.dex */
public final class ScrollerCompat {
    private final boolean mIsIcsOrNewer;
    public OverScroller mScroller;

    public static ScrollerCompat create(Context context, Interpolator interpolator) {
        return new ScrollerCompat(Build.VERSION.SDK_INT >= 14, context, interpolator);
    }

    private ScrollerCompat(boolean isIcsOrNewer, Context context, Interpolator interpolator) {
        this.mIsIcsOrNewer = isIcsOrNewer;
        this.mScroller = interpolator != null ? new OverScroller(context, interpolator) : new OverScroller(context);
    }

    public final float getCurrVelocity() {
        if (this.mIsIcsOrNewer) {
            return this.mScroller.getCurrVelocity();
        }
        return 0.0f;
    }

    public final void startScroll(int startX, int startY, int dx, int dy, int duration) {
        this.mScroller.startScroll(startX, startY, dx, dy, duration);
    }

    public final void fling$69c647f5(int startY, int velocityX, int velocityY, int minX, int maxX, int minY, int maxY) {
        this.mScroller.fling(0, startY, velocityX, velocityY, minX, maxX, minY, maxY);
    }

    public final boolean springBack$6046c8d9(int startX, int startY, int maxY) {
        return this.mScroller.springBack(startX, startY, 0, 0, 0, maxY);
    }
}
