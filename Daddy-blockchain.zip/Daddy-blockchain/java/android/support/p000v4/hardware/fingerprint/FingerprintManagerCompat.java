package android.support.p000v4.hardware.fingerprint;

import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.support.p000v4.p001os.CancellationSignal;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.Mac;

/* renamed from: android.support.v4.hardware.fingerprint.FingerprintManagerCompat */
/* loaded from: classes.dex */
public final class FingerprintManagerCompat {
    static final FingerprintManagerCompatImpl IMPL;
    private Context mContext;

    /* renamed from: android.support.v4.hardware.fingerprint.FingerprintManagerCompat$FingerprintManagerCompatImpl */
    /* loaded from: classes.dex */
    private interface FingerprintManagerCompatImpl {
        void authenticate$565d2525(Context context, CryptoObject cryptoObject, CancellationSignal cancellationSignal, AuthenticationCallback authenticationCallback);

        boolean hasEnrolledFingerprints(Context context);

        boolean isHardwareDetected(Context context);
    }

    public static FingerprintManagerCompat from(Context context) {
        return new FingerprintManagerCompat(context);
    }

    private FingerprintManagerCompat(Context context) {
        this.mContext = context;
    }

    static {
        if (Build.VERSION.SDK_INT >= 23) {
            IMPL = new Api23FingerprintManagerCompatImpl();
        } else {
            IMPL = new LegacyFingerprintManagerCompatImpl();
        }
    }

    public final boolean hasEnrolledFingerprints() {
        return IMPL.hasEnrolledFingerprints(this.mContext);
    }

    public final boolean isHardwareDetected() {
        return IMPL.isHardwareDetected(this.mContext);
    }

    public final void authenticate$4736b963(CryptoObject crypto, CancellationSignal cancel, AuthenticationCallback callback) {
        IMPL.authenticate$565d2525(this.mContext, crypto, cancel, callback);
    }

    /* renamed from: android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject */
    /* loaded from: classes.dex */
    public static class CryptoObject {
        final Cipher mCipher;
        final Mac mMac;
        final Signature mSignature;

        public CryptoObject(Signature signature) {
            this.mSignature = signature;
            this.mCipher = null;
            this.mMac = null;
        }

        public CryptoObject(Cipher cipher) {
            this.mCipher = cipher;
            this.mSignature = null;
            this.mMac = null;
        }

        public CryptoObject(Mac mac) {
            this.mMac = mac;
            this.mCipher = null;
            this.mSignature = null;
        }

        public final Cipher getCipher() {
            return this.mCipher;
        }
    }

    /* renamed from: android.support.v4.hardware.fingerprint.FingerprintManagerCompat$AuthenticationResult */
    /* loaded from: classes.dex */
    public static final class AuthenticationResult {
        private CryptoObject mCryptoObject;

        public AuthenticationResult(CryptoObject crypto) {
            this.mCryptoObject = crypto;
        }

        public final CryptoObject getCryptoObject() {
            return this.mCryptoObject;
        }
    }

    /* renamed from: android.support.v4.hardware.fingerprint.FingerprintManagerCompat$AuthenticationCallback */
    /* loaded from: classes.dex */
    public static abstract class AuthenticationCallback {
        public void onAuthenticationError(int errMsgId, CharSequence errString) {
        }

        public void onAuthenticationHelp(int helpMsgId, CharSequence helpString) {
        }

        public void onAuthenticationSucceeded(AuthenticationResult result) {
        }

        public void onAuthenticationFailed() {
        }
    }

    /* renamed from: android.support.v4.hardware.fingerprint.FingerprintManagerCompat$LegacyFingerprintManagerCompatImpl */
    /* loaded from: classes.dex */
    private static class LegacyFingerprintManagerCompatImpl implements FingerprintManagerCompatImpl {
        @Override // android.support.p000v4.hardware.fingerprint.FingerprintManagerCompat.FingerprintManagerCompatImpl
        public final boolean hasEnrolledFingerprints(Context context) {
            return false;
        }

        @Override // android.support.p000v4.hardware.fingerprint.FingerprintManagerCompat.FingerprintManagerCompatImpl
        public final boolean isHardwareDetected(Context context) {
            return false;
        }

        @Override // android.support.p000v4.hardware.fingerprint.FingerprintManagerCompat.FingerprintManagerCompatImpl
        public final void authenticate$565d2525(Context context, CryptoObject crypto, CancellationSignal cancel, AuthenticationCallback callback) {
        }
    }

    /* renamed from: android.support.v4.hardware.fingerprint.FingerprintManagerCompat$Api23FingerprintManagerCompatImpl */
    /* loaded from: classes.dex */
    private static class Api23FingerprintManagerCompatImpl implements FingerprintManagerCompatImpl {
        @Override // android.support.p000v4.hardware.fingerprint.FingerprintManagerCompat.FingerprintManagerCompatImpl
        public final boolean hasEnrolledFingerprints(Context context) {
            FingerprintManager fingerprintManagerOrNull = FingerprintManagerCompatApi23.getFingerprintManagerOrNull(context);
            return fingerprintManagerOrNull != null && fingerprintManagerOrNull.hasEnrolledFingerprints();
        }

        @Override // android.support.p000v4.hardware.fingerprint.FingerprintManagerCompat.FingerprintManagerCompatImpl
        public final boolean isHardwareDetected(Context context) {
            FingerprintManager fingerprintManagerOrNull = FingerprintManagerCompatApi23.getFingerprintManagerOrNull(context);
            return fingerprintManagerOrNull != null && fingerprintManagerOrNull.isHardwareDetected();
        }

        /* JADX WARN: Removed duplicated region for block: B:11:0x0020  */
        /* JADX WARN: Removed duplicated region for block: B:24:0x0055  */
        /* JADX WARN: Removed duplicated region for block: B:32:? A[RETURN, SYNTHETIC] */
        /* JADX WARN: Removed duplicated region for block: B:8:0x0011  */
        @Override // android.support.p000v4.hardware.fingerprint.FingerprintManagerCompat.FingerprintManagerCompatImpl
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final void authenticate$565d2525(android.content.Context r8, android.support.p000v4.hardware.fingerprint.FingerprintManagerCompat.CryptoObject r9, android.support.p000v4.p001os.CancellationSignal r10, final android.support.p000v4.hardware.fingerprint.FingerprintManagerCompat.AuthenticationCallback r11) {
            /*
                r7 = this;
                r5 = 0
                if (r9 == 0) goto L53
                javax.crypto.Cipher r0 = r9.mCipher
                if (r0 == 0) goto L39
                android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject r0 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject
                javax.crypto.Cipher r1 = r9.mCipher
                r0.<init>(r1)
                r3 = r0
            Lf:
                if (r10 == 0) goto L55
                java.lang.Object r2 = r10.getCancellationSignalObject()
            L15:
                android.support.v4.hardware.fingerprint.FingerprintManagerCompat$Api23FingerprintManagerCompatImpl$1 r6 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompat$Api23FingerprintManagerCompatImpl$1
                r6.<init>()
                android.hardware.fingerprint.FingerprintManager r0 = android.support.p000v4.hardware.fingerprint.FingerprintManagerCompatApi23.getFingerprintManagerOrNull(r8)
                if (r0 == 0) goto L38
                if (r3 == 0) goto L6f
                javax.crypto.Cipher r1 = r3.mCipher
                if (r1 == 0) goto L57
                android.hardware.fingerprint.FingerprintManager$CryptoObject r1 = new android.hardware.fingerprint.FingerprintManager$CryptoObject
                javax.crypto.Cipher r3 = r3.mCipher
                r1.<init>(r3)
            L2d:
                android.os.CancellationSignal r2 = (android.os.CancellationSignal) r2
                r3 = 0
                android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$1 r4 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$1
                r4.<init>()
                r0.authenticate(r1, r2, r3, r4, r5)
            L38:
                return
            L39:
                java.security.Signature r0 = r9.mSignature
                if (r0 == 0) goto L46
                android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject r0 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject
                java.security.Signature r1 = r9.mSignature
                r0.<init>(r1)
                r3 = r0
                goto Lf
            L46:
                javax.crypto.Mac r0 = r9.mMac
                if (r0 == 0) goto L53
                android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject r0 = new android.support.v4.hardware.fingerprint.FingerprintManagerCompatApi23$CryptoObject
                javax.crypto.Mac r1 = r9.mMac
                r0.<init>(r1)
                r3 = r0
                goto Lf
            L53:
                r3 = r5
                goto Lf
            L55:
                r2 = r5
                goto L15
            L57:
                java.security.Signature r1 = r3.mSignature
                if (r1 == 0) goto L63
                android.hardware.fingerprint.FingerprintManager$CryptoObject r1 = new android.hardware.fingerprint.FingerprintManager$CryptoObject
                java.security.Signature r3 = r3.mSignature
                r1.<init>(r3)
                goto L2d
            L63:
                javax.crypto.Mac r1 = r3.mMac
                if (r1 == 0) goto L6f
                android.hardware.fingerprint.FingerprintManager$CryptoObject r1 = new android.hardware.fingerprint.FingerprintManager$CryptoObject
                javax.crypto.Mac r3 = r3.mMac
                r1.<init>(r3)
                goto L2d
            L6f:
                r1 = r5
                goto L2d
            */
            throw new UnsupportedOperationException("Method not decompiled: android.support.p000v4.hardware.fingerprint.FingerprintManagerCompat.Api23FingerprintManagerCompatImpl.authenticate$565d2525(android.content.Context, android.support.v4.hardware.fingerprint.FingerprintManagerCompat$CryptoObject, android.support.v4.os.CancellationSignal, android.support.v4.hardware.fingerprint.FingerprintManagerCompat$AuthenticationCallback):void");
        }
    }
}
