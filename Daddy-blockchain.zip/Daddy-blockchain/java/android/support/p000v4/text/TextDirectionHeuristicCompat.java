package android.support.p000v4.text;

/* renamed from: android.support.v4.text.TextDirectionHeuristicCompat */
/* loaded from: classes.dex */
public interface TextDirectionHeuristicCompat {
    boolean isRtl$4d1ed0c3(CharSequence charSequence, int i);
}
