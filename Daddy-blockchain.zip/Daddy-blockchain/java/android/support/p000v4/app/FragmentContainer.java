package android.support.p000v4.app;

import android.view.View;

/* renamed from: android.support.v4.app.FragmentContainer */
/* loaded from: classes.dex */
public abstract class FragmentContainer {
    public abstract View onFindViewById(int i);

    public abstract boolean onHasView();
}
