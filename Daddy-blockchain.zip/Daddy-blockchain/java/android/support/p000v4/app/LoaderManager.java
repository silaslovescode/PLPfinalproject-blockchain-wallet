package android.support.p000v4.app;

import android.support.p000v4.content.Loader;

/* renamed from: android.support.v4.app.LoaderManager */
/* loaded from: classes.dex */
public abstract class LoaderManager {

    /* renamed from: android.support.v4.app.LoaderManager$LoaderCallbacks */
    /* loaded from: classes.dex */
    public interface LoaderCallbacks<D> {
        Loader<D> onCreateLoader$e57f803();
    }

    public boolean hasRunningLoaders() {
        return false;
    }
}
