package android.support.p000v4.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.p000v4.content.IntentCompat;

/* renamed from: android.support.v4.app.NavUtils */
/* loaded from: classes.dex */
public final class NavUtils {
    private static final NavUtilsImpl IMPL;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: android.support.v4.app.NavUtils$NavUtilsImpl */
    /* loaded from: classes.dex */
    public interface NavUtilsImpl {
        Intent getParentActivityIntent(Activity activity);

        String getParentActivityName(Context context, ActivityInfo activityInfo);

        void navigateUpTo(Activity activity, Intent intent);

        boolean shouldUpRecreateTask(Activity activity, Intent intent);
    }

    /* renamed from: android.support.v4.app.NavUtils$NavUtilsImplBase */
    /* loaded from: classes.dex */
    static class NavUtilsImplBase implements NavUtilsImpl {
        NavUtilsImplBase() {
        }

        @Override // android.support.p000v4.app.NavUtils.NavUtilsImpl
        public Intent getParentActivityIntent(Activity activity) {
            Intent intent = null;
            String parentName = NavUtils.getParentActivityName(activity);
            if (parentName != null) {
                ComponentName target = new ComponentName(activity, parentName);
                try {
                    if (NavUtils.getParentActivityName(activity, target) == null) {
                        intent = IntentCompat.makeMainActivity(target);
                    } else {
                        intent = new Intent().setComponent(target);
                    }
                } catch (PackageManager.NameNotFoundException e) {
                    new StringBuilder("getParentActivityIntent: bad parentActivityName '").append(parentName).append("' in manifest");
                }
            }
            return intent;
        }

        @Override // android.support.p000v4.app.NavUtils.NavUtilsImpl
        public boolean shouldUpRecreateTask(Activity activity, Intent targetIntent) {
            String action = activity.getIntent().getAction();
            return action != null && !action.equals("android.intent.action.MAIN");
        }

        @Override // android.support.p000v4.app.NavUtils.NavUtilsImpl
        public void navigateUpTo(Activity activity, Intent upIntent) {
            upIntent.addFlags(67108864);
            activity.startActivity(upIntent);
            activity.finish();
        }

        @Override // android.support.p000v4.app.NavUtils.NavUtilsImpl
        public String getParentActivityName(Context context, ActivityInfo info2) {
            String parentActivity;
            if (info2.metaData != null && (parentActivity = info2.metaData.getString("android.support.PARENT_ACTIVITY")) != null) {
                if (parentActivity.charAt(0) == '.') {
                    return context.getPackageName() + parentActivity;
                }
                return parentActivity;
            }
            return null;
        }
    }

    /* renamed from: android.support.v4.app.NavUtils$NavUtilsImplJB */
    /* loaded from: classes.dex */
    static class NavUtilsImplJB extends NavUtilsImplBase {
        NavUtilsImplJB() {
        }

        @Override // android.support.p000v4.app.NavUtils.NavUtilsImplBase, android.support.p000v4.app.NavUtils.NavUtilsImpl
        public final Intent getParentActivityIntent(Activity activity) {
            Intent result = activity.getParentActivityIntent();
            if (result != null) {
                return result;
            }
            return super.getParentActivityIntent(activity);
        }

        @Override // android.support.p000v4.app.NavUtils.NavUtilsImplBase, android.support.p000v4.app.NavUtils.NavUtilsImpl
        public final boolean shouldUpRecreateTask(Activity activity, Intent targetIntent) {
            return activity.shouldUpRecreateTask(targetIntent);
        }

        @Override // android.support.p000v4.app.NavUtils.NavUtilsImplBase, android.support.p000v4.app.NavUtils.NavUtilsImpl
        public final void navigateUpTo(Activity activity, Intent upIntent) {
            activity.navigateUpTo(upIntent);
        }

        @Override // android.support.p000v4.app.NavUtils.NavUtilsImplBase, android.support.p000v4.app.NavUtils.NavUtilsImpl
        public final String getParentActivityName(Context context, ActivityInfo info2) {
            String result = info2.parentActivityName;
            if (result == null) {
                return super.getParentActivityName(context, info2);
            }
            return result;
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 16) {
            IMPL = new NavUtilsImplJB();
        } else {
            IMPL = new NavUtilsImplBase();
        }
    }

    public static boolean shouldUpRecreateTask(Activity sourceActivity, Intent targetIntent) {
        return IMPL.shouldUpRecreateTask(sourceActivity, targetIntent);
    }

    public static void navigateUpTo(Activity sourceActivity, Intent upIntent) {
        IMPL.navigateUpTo(sourceActivity, upIntent);
    }

    public static Intent getParentActivityIntent(Activity sourceActivity) {
        return IMPL.getParentActivityIntent(sourceActivity);
    }

    public static Intent getParentActivityIntent(Context context, ComponentName componentName) throws PackageManager.NameNotFoundException {
        String parentActivity = getParentActivityName(context, componentName);
        if (parentActivity == null) {
            return null;
        }
        ComponentName target = new ComponentName(componentName.getPackageName(), parentActivity);
        if (getParentActivityName(context, target) == null) {
            return IntentCompat.makeMainActivity(target);
        }
        return new Intent().setComponent(target);
    }

    public static String getParentActivityName(Activity sourceActivity) {
        try {
            return getParentActivityName(sourceActivity, sourceActivity.getComponentName());
        } catch (PackageManager.NameNotFoundException e) {
            throw new IllegalArgumentException(e);
        }
    }

    public static String getParentActivityName(Context context, ComponentName componentName) throws PackageManager.NameNotFoundException {
        ActivityInfo info2 = context.getPackageManager().getActivityInfo(componentName, NotificationCompat.FLAG_HIGH_PRIORITY);
        return IMPL.getParentActivityName(context, info2);
    }
}
