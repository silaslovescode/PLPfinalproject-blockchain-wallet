package android.support.p000v4.view;

import android.view.ViewGroup;

/* renamed from: android.support.v4.view.NestedScrollingParentHelper */
/* loaded from: classes.dex */
public final class NestedScrollingParentHelper {
    public int mNestedScrollAxes;
    private final ViewGroup mViewGroup;

    public NestedScrollingParentHelper(ViewGroup viewGroup) {
        this.mViewGroup = viewGroup;
    }
}
