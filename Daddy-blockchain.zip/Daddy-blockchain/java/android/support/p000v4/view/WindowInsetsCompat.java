package android.support.p000v4.view;

import android.os.Build;
import android.view.WindowInsets;

/* renamed from: android.support.v4.view.WindowInsetsCompat */
/* loaded from: classes.dex */
public final class WindowInsetsCompat {
    public static final WindowInsetsCompatImpl IMPL;
    public final Object mInsets;

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: android.support.v4.view.WindowInsetsCompat$WindowInsetsCompatImpl */
    /* loaded from: classes.dex */
    public interface WindowInsetsCompatImpl {
        WindowInsetsCompat consumeSystemWindowInsets(Object obj);

        int getSystemWindowInsetBottom(Object obj);

        int getSystemWindowInsetLeft(Object obj);

        int getSystemWindowInsetRight(Object obj);

        int getSystemWindowInsetTop(Object obj);

        boolean hasSystemWindowInsets(Object obj);

        boolean isConsumed(Object obj);

        WindowInsetsCompat replaceSystemWindowInsets(Object obj, int i, int i2, int i3, int i4);
    }

    /* renamed from: android.support.v4.view.WindowInsetsCompat$WindowInsetsCompatBaseImpl */
    /* loaded from: classes.dex */
    private static class WindowInsetsCompatBaseImpl implements WindowInsetsCompatImpl {
        WindowInsetsCompatBaseImpl() {
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public int getSystemWindowInsetLeft(Object insets) {
            return 0;
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public int getSystemWindowInsetTop(Object insets) {
            return 0;
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public int getSystemWindowInsetRight(Object insets) {
            return 0;
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public int getSystemWindowInsetBottom(Object insets) {
            return 0;
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public boolean hasSystemWindowInsets(Object insets) {
            return false;
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public boolean isConsumed(Object insets) {
            return false;
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public WindowInsetsCompat consumeSystemWindowInsets(Object insets) {
            return null;
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public WindowInsetsCompat replaceSystemWindowInsets(Object insets, int left, int top, int right, int bottom) {
            return null;
        }
    }

    /* renamed from: android.support.v4.view.WindowInsetsCompat$WindowInsetsCompatApi20Impl */
    /* loaded from: classes.dex */
    private static class WindowInsetsCompatApi20Impl extends WindowInsetsCompatBaseImpl {
        WindowInsetsCompatApi20Impl() {
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatBaseImpl, android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public final WindowInsetsCompat consumeSystemWindowInsets(Object insets) {
            return new WindowInsetsCompat(((WindowInsets) insets).consumeSystemWindowInsets());
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatBaseImpl, android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public final WindowInsetsCompat replaceSystemWindowInsets(Object insets, int left, int top, int right, int bottom) {
            return new WindowInsetsCompat(((WindowInsets) insets).replaceSystemWindowInsets(left, top, right, bottom));
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatBaseImpl, android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public final int getSystemWindowInsetBottom(Object insets) {
            return ((WindowInsets) insets).getSystemWindowInsetBottom();
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatBaseImpl, android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public final int getSystemWindowInsetLeft(Object insets) {
            return ((WindowInsets) insets).getSystemWindowInsetLeft();
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatBaseImpl, android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public final int getSystemWindowInsetRight(Object insets) {
            return ((WindowInsets) insets).getSystemWindowInsetRight();
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatBaseImpl, android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public final int getSystemWindowInsetTop(Object insets) {
            return ((WindowInsets) insets).getSystemWindowInsetTop();
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatBaseImpl, android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public final boolean hasSystemWindowInsets(Object insets) {
            return ((WindowInsets) insets).hasSystemWindowInsets();
        }
    }

    /* renamed from: android.support.v4.view.WindowInsetsCompat$WindowInsetsCompatApi21Impl */
    /* loaded from: classes.dex */
    private static class WindowInsetsCompatApi21Impl extends WindowInsetsCompatApi20Impl {
        WindowInsetsCompatApi21Impl() {
        }

        @Override // android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatBaseImpl, android.support.p000v4.view.WindowInsetsCompat.WindowInsetsCompatImpl
        public final boolean isConsumed(Object insets) {
            return ((WindowInsets) insets).isConsumed();
        }
    }

    static {
        int version = Build.VERSION.SDK_INT;
        if (version >= 21) {
            IMPL = new WindowInsetsCompatApi21Impl();
        } else if (version >= 20) {
            IMPL = new WindowInsetsCompatApi20Impl();
        } else {
            IMPL = new WindowInsetsCompatBaseImpl();
        }
    }

    WindowInsetsCompat(Object insets) {
        this.mInsets = insets;
    }

    public final int getSystemWindowInsetLeft() {
        return IMPL.getSystemWindowInsetLeft(this.mInsets);
    }

    public final int getSystemWindowInsetTop() {
        return IMPL.getSystemWindowInsetTop(this.mInsets);
    }

    public final int getSystemWindowInsetRight() {
        return IMPL.getSystemWindowInsetRight(this.mInsets);
    }

    public final int getSystemWindowInsetBottom() {
        return IMPL.getSystemWindowInsetBottom(this.mInsets);
    }

    public final boolean isConsumed() {
        return IMPL.isConsumed(this.mInsets);
    }

    public final WindowInsetsCompat consumeSystemWindowInsets() {
        return IMPL.consumeSystemWindowInsets(this.mInsets);
    }

    public final WindowInsetsCompat replaceSystemWindowInsets(int left, int top, int right, int bottom) {
        return IMPL.replaceSystemWindowInsets(this.mInsets, left, top, right, bottom);
    }

    public final boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        WindowInsetsCompat other = (WindowInsetsCompat) o;
        return this.mInsets == null ? other.mInsets == null : this.mInsets.equals(other.mInsets);
    }

    public final int hashCode() {
        if (this.mInsets == null) {
            return 0;
        }
        return this.mInsets.hashCode();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static WindowInsetsCompat wrap(Object insets) {
        if (insets == null) {
            return null;
        }
        return new WindowInsetsCompat(insets);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Object unwrap(WindowInsetsCompat insets) {
        if (insets == null) {
            return null;
        }
        return insets.mInsets;
    }
}
