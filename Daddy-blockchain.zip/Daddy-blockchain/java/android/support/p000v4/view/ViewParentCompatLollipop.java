package android.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.View;
import android.view.ViewParent;

@TargetApi(21)
/* renamed from: android.support.v4.view.ViewParentCompatLollipop */
/* loaded from: classes.dex */
final class ViewParentCompatLollipop {
    public static boolean onStartNestedScroll(ViewParent parent, View child, View target, int nestedScrollAxes) {
        try {
            return parent.onStartNestedScroll(child, target, nestedScrollAxes);
        } catch (AbstractMethodError e) {
            new StringBuilder("ViewParent ").append(parent).append(" does not implement interface method onStartNestedScroll");
            return false;
        }
    }

    public static boolean onNestedFling(ViewParent parent, View target, float velocityX, float velocityY, boolean consumed) {
        try {
            return parent.onNestedFling(target, velocityX, velocityY, consumed);
        } catch (AbstractMethodError e) {
            new StringBuilder("ViewParent ").append(parent).append(" does not implement interface method onNestedFling");
            return false;
        }
    }

    public static boolean onNestedPreFling(ViewParent parent, View target, float velocityX, float velocityY) {
        try {
            return parent.onNestedPreFling(target, velocityX, velocityY);
        } catch (AbstractMethodError e) {
            new StringBuilder("ViewParent ").append(parent).append(" does not implement interface method onNestedPreFling");
            return false;
        }
    }
}
