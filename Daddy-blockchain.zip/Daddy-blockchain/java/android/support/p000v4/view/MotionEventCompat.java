package android.support.p000v4.view;

import android.os.Build;
import android.view.MotionEvent;

/* renamed from: android.support.v4.view.MotionEventCompat */
/* loaded from: classes.dex */
public final class MotionEventCompat {
    static final MotionEventVersionImpl IMPL;

    /* renamed from: android.support.v4.view.MotionEventCompat$MotionEventVersionImpl */
    /* loaded from: classes.dex */
    interface MotionEventVersionImpl {
        float getAxisValue(MotionEvent motionEvent, int i);
    }

    /* renamed from: android.support.v4.view.MotionEventCompat$BaseMotionEventVersionImpl */
    /* loaded from: classes.dex */
    static class BaseMotionEventVersionImpl implements MotionEventVersionImpl {
        BaseMotionEventVersionImpl() {
        }

        @Override // android.support.p000v4.view.MotionEventCompat.MotionEventVersionImpl
        public float getAxisValue(MotionEvent event, int axis) {
            return 0.0f;
        }
    }

    /* renamed from: android.support.v4.view.MotionEventCompat$HoneycombMr1MotionEventVersionImpl */
    /* loaded from: classes.dex */
    static class HoneycombMr1MotionEventVersionImpl extends BaseMotionEventVersionImpl {
        HoneycombMr1MotionEventVersionImpl() {
        }

        @Override // android.support.p000v4.view.MotionEventCompat.BaseMotionEventVersionImpl, android.support.p000v4.view.MotionEventCompat.MotionEventVersionImpl
        public final float getAxisValue(MotionEvent event, int axis) {
            return event.getAxisValue(axis);
        }
    }

    /* renamed from: android.support.v4.view.MotionEventCompat$ICSMotionEventVersionImpl */
    /* loaded from: classes.dex */
    private static class ICSMotionEventVersionImpl extends HoneycombMr1MotionEventVersionImpl {
        ICSMotionEventVersionImpl() {
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 14) {
            IMPL = new ICSMotionEventVersionImpl();
        } else if (Build.VERSION.SDK_INT >= 12) {
            IMPL = new HoneycombMr1MotionEventVersionImpl();
        } else {
            IMPL = new BaseMotionEventVersionImpl();
        }
    }

    public static int getActionMasked(MotionEvent event) {
        return event.getAction() & 255;
    }

    public static int getActionIndex(MotionEvent event) {
        return (event.getAction() & 65280) >> 8;
    }

    public static float getAxisValue(MotionEvent event, int axis) {
        return IMPL.getAxisValue(event, axis);
    }
}
