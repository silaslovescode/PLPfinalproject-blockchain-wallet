package android.support.p000v4.view;

import android.os.Build;
import android.support.p000v4.internal.view.SupportMenuItem;
import android.view.MenuItem;
import android.view.View;

/* renamed from: android.support.v4.view.MenuItemCompat */
/* loaded from: classes.dex */
public final class MenuItemCompat {
    static final MenuVersionImpl IMPL;

    /* renamed from: android.support.v4.view.MenuItemCompat$MenuVersionImpl */
    /* loaded from: classes.dex */
    interface MenuVersionImpl {
        boolean expandActionView(MenuItem menuItem);

        View getActionView(MenuItem menuItem);

        boolean isActionViewExpanded(MenuItem menuItem);

        MenuItem setActionView(MenuItem menuItem, int i);

        MenuItem setActionView(MenuItem menuItem, View view);

        void setShowAsAction(MenuItem menuItem, int i);
    }

    /* renamed from: android.support.v4.view.MenuItemCompat$OnActionExpandListener */
    /* loaded from: classes.dex */
    public interface OnActionExpandListener {
        boolean onMenuItemActionCollapse(MenuItem menuItem);

        boolean onMenuItemActionExpand(MenuItem menuItem);
    }

    /* renamed from: android.support.v4.view.MenuItemCompat$BaseMenuVersionImpl */
    /* loaded from: classes.dex */
    static class BaseMenuVersionImpl implements MenuVersionImpl {
        BaseMenuVersionImpl() {
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final void setShowAsAction(MenuItem item, int actionEnum) {
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final MenuItem setActionView(MenuItem item, View view) {
            return item;
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final MenuItem setActionView(MenuItem item, int resId) {
            return item;
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final View getActionView(MenuItem item) {
            return null;
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final boolean expandActionView(MenuItem item) {
            return false;
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final boolean isActionViewExpanded(MenuItem item) {
            return false;
        }
    }

    /* renamed from: android.support.v4.view.MenuItemCompat$HoneycombMenuVersionImpl */
    /* loaded from: classes.dex */
    static class HoneycombMenuVersionImpl implements MenuVersionImpl {
        HoneycombMenuVersionImpl() {
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public boolean expandActionView(MenuItem item) {
            return false;
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public boolean isActionViewExpanded(MenuItem item) {
            return false;
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final void setShowAsAction(MenuItem item, int actionEnum) {
            item.setShowAsAction(actionEnum);
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final MenuItem setActionView(MenuItem item, View view) {
            return item.setActionView(view);
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final MenuItem setActionView(MenuItem item, int resId) {
            return item.setActionView(resId);
        }

        @Override // android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final View getActionView(MenuItem item) {
            return item.getActionView();
        }
    }

    /* renamed from: android.support.v4.view.MenuItemCompat$IcsMenuVersionImpl */
    /* loaded from: classes.dex */
    static class IcsMenuVersionImpl extends HoneycombMenuVersionImpl {
        IcsMenuVersionImpl() {
        }

        @Override // android.support.p000v4.view.MenuItemCompat.HoneycombMenuVersionImpl, android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final boolean expandActionView(MenuItem item) {
            return item.expandActionView();
        }

        @Override // android.support.p000v4.view.MenuItemCompat.HoneycombMenuVersionImpl, android.support.p000v4.view.MenuItemCompat.MenuVersionImpl
        public final boolean isActionViewExpanded(MenuItem item) {
            return item.isActionViewExpanded();
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 14) {
            IMPL = new IcsMenuVersionImpl();
        } else if (Build.VERSION.SDK_INT >= 11) {
            IMPL = new HoneycombMenuVersionImpl();
        } else {
            IMPL = new BaseMenuVersionImpl();
        }
    }

    public static void setShowAsAction(MenuItem item, int actionEnum) {
        if (item instanceof SupportMenuItem) {
            ((SupportMenuItem) item).setShowAsAction(actionEnum);
        } else {
            IMPL.setShowAsAction(item, actionEnum);
        }
    }

    public static MenuItem setActionView(MenuItem item, View view) {
        return item instanceof SupportMenuItem ? ((SupportMenuItem) item).mo69setActionView(view) : IMPL.setActionView(item, view);
    }

    public static MenuItem setActionView(MenuItem item, int resId) {
        return item instanceof SupportMenuItem ? ((SupportMenuItem) item).mo68setActionView(resId) : IMPL.setActionView(item, resId);
    }

    public static View getActionView(MenuItem item) {
        return item instanceof SupportMenuItem ? ((SupportMenuItem) item).getActionView() : IMPL.getActionView(item);
    }

    public static MenuItem setActionProvider(MenuItem item, ActionProvider provider) {
        if (item instanceof SupportMenuItem) {
            return ((SupportMenuItem) item).setSupportActionProvider(provider);
        }
        return item;
    }

    public static boolean expandActionView(MenuItem item) {
        return item instanceof SupportMenuItem ? ((SupportMenuItem) item).expandActionView() : IMPL.expandActionView(item);
    }

    public static boolean isActionViewExpanded(MenuItem item) {
        return item instanceof SupportMenuItem ? ((SupportMenuItem) item).isActionViewExpanded() : IMPL.isActionViewExpanded(item);
    }
}
