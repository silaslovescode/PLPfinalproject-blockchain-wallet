package android.support.p000v4.view;

/* renamed from: android.support.v4.view.NestedScrollingChild */
/* loaded from: classes.dex */
public interface NestedScrollingChild {
    boolean isNestedScrollingEnabled();

    void stopNestedScroll();
}
