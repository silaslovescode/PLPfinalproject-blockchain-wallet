package android.support.p000v4.view.accessibility;

import android.annotation.TargetApi;
import java.util.List;

@TargetApi(16)
/* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean */
/* loaded from: classes.dex */
final class AccessibilityNodeProviderCompatJellyBean {

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean$AccessibilityNodeInfoBridge */
    /* loaded from: classes.dex */
    interface AccessibilityNodeInfoBridge {
        Object createAccessibilityNodeInfo$54cf32c4();

        List<Object> findAccessibilityNodeInfosByText$2393931d();

        boolean performAction$5985f823();
    }
}
