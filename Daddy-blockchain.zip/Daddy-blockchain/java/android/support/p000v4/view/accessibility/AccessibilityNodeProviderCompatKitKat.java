package android.support.p000v4.view.accessibility;

import android.annotation.TargetApi;
import java.util.List;

@TargetApi(19)
/* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompatKitKat */
/* loaded from: classes.dex */
final class AccessibilityNodeProviderCompatKitKat {

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompatKitKat$AccessibilityNodeInfoBridge */
    /* loaded from: classes.dex */
    interface AccessibilityNodeInfoBridge {
        Object createAccessibilityNodeInfo$54cf32c4();

        List<Object> findAccessibilityNodeInfosByText$2393931d();

        Object findFocus$54cf32c4();

        boolean performAction$5985f823();
    }
}
