package android.support.p000v4.view.accessibility;

import android.graphics.Rect;
import android.os.Build;
import android.support.p000v4.app.NotificationCompat;
import android.support.p002v7.widget.RecyclerView;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;

/* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat */
/* loaded from: classes.dex */
public final class AccessibilityNodeInfoCompat {
    public static final AccessibilityNodeInfoImpl IMPL;
    public final Object mInfo;
    public int mParentVirtualDescendantId = -1;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoImpl */
    /* loaded from: classes.dex */
    public interface AccessibilityNodeInfoImpl {
        void addAction(Object obj, int i);

        void addChild(Object obj, View view);

        Object getActionContextClick();

        Object getActionScrollDown();

        Object getActionScrollLeft();

        Object getActionScrollRight();

        Object getActionScrollToPosition();

        Object getActionScrollUp();

        Object getActionSetProgress();

        Object getActionShowOnScreen();

        int getActions(Object obj);

        void getBoundsInParent(Object obj, Rect rect);

        void getBoundsInScreen(Object obj, Rect rect);

        CharSequence getClassName(Object obj);

        int getCollectionItemColumnIndex(Object obj);

        int getCollectionItemColumnSpan(Object obj);

        Object getCollectionItemInfo(Object obj);

        int getCollectionItemRowIndex(Object obj);

        int getCollectionItemRowSpan(Object obj);

        CharSequence getContentDescription(Object obj);

        int getMovementGranularities(Object obj);

        CharSequence getPackageName(Object obj);

        CharSequence getText(Object obj);

        String getViewIdResourceName(Object obj);

        boolean isAccessibilityFocused(Object obj);

        boolean isCheckable(Object obj);

        boolean isChecked(Object obj);

        boolean isClickable(Object obj);

        boolean isCollectionItemSelected(Object obj);

        boolean isEnabled(Object obj);

        boolean isFocusable(Object obj);

        boolean isFocused(Object obj);

        boolean isLongClickable(Object obj);

        boolean isPassword(Object obj);

        boolean isScrollable(Object obj);

        boolean isSelected(Object obj);

        boolean isVisibleToUser(Object obj);

        Object newAccessibilityAction$442b94a0(int i);

        Object obtain(Object obj);

        Object obtainCollectionInfo(int i, int i2, boolean z, int i3);

        Object obtainCollectionItemInfo(int i, int i2, int i3, int i4, boolean z, boolean z2);

        void recycle(Object obj);

        boolean removeAction(Object obj, Object obj2);

        void setAccessibilityFocused(Object obj, boolean z);

        void setBoundsInParent(Object obj, Rect rect);

        void setBoundsInScreen(Object obj, Rect rect);

        void setCheckable(Object obj, boolean z);

        void setChecked(Object obj, boolean z);

        void setClassName(Object obj, CharSequence charSequence);

        void setClickable(Object obj, boolean z);

        void setCollectionInfo(Object obj, Object obj2);

        void setCollectionItemInfo(Object obj, Object obj2);

        void setContentDescription(Object obj, CharSequence charSequence);

        void setContentInvalid$4cfd3ce3(Object obj);

        void setDismissable(Object obj, boolean z);

        void setEnabled(Object obj, boolean z);

        void setError(Object obj, CharSequence charSequence);

        void setFocusable(Object obj, boolean z);

        void setFocused(Object obj, boolean z);

        void setLabelFor(Object obj, View view);

        void setLongClickable(Object obj, boolean z);

        void setMovementGranularities(Object obj, int i);

        void setPackageName(Object obj, CharSequence charSequence);

        void setParent(Object obj, View view);

        void setScrollable(Object obj, boolean z);

        void setSelected(Object obj, boolean z);

        void setSource(Object obj, View view);

        void setText(Object obj, CharSequence charSequence);

        void setVisibleToUser(Object obj, boolean z);
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityActionCompat */
    /* loaded from: classes.dex */
    public static class AccessibilityActionCompat {
        final Object mAction;
        public static final AccessibilityActionCompat ACTION_FOCUS = new AccessibilityActionCompat(1);
        public static final AccessibilityActionCompat ACTION_CLEAR_FOCUS = new AccessibilityActionCompat(2);
        public static final AccessibilityActionCompat ACTION_SELECT = new AccessibilityActionCompat(4);
        public static final AccessibilityActionCompat ACTION_CLEAR_SELECTION = new AccessibilityActionCompat(8);
        public static final AccessibilityActionCompat ACTION_CLICK = new AccessibilityActionCompat(16);
        public static final AccessibilityActionCompat ACTION_LONG_CLICK = new AccessibilityActionCompat(32);
        public static final AccessibilityActionCompat ACTION_ACCESSIBILITY_FOCUS = new AccessibilityActionCompat(64);
        public static final AccessibilityActionCompat ACTION_CLEAR_ACCESSIBILITY_FOCUS = new AccessibilityActionCompat((int) NotificationCompat.FLAG_HIGH_PRIORITY);
        public static final AccessibilityActionCompat ACTION_NEXT_AT_MOVEMENT_GRANULARITY = new AccessibilityActionCompat((int) NotificationCompat.FLAG_LOCAL_ONLY);
        public static final AccessibilityActionCompat ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY = new AccessibilityActionCompat((int) NotificationCompat.FLAG_GROUP_SUMMARY);
        public static final AccessibilityActionCompat ACTION_NEXT_HTML_ELEMENT = new AccessibilityActionCompat(1024);
        public static final AccessibilityActionCompat ACTION_PREVIOUS_HTML_ELEMENT = new AccessibilityActionCompat((int) RecyclerView.ItemAnimator.FLAG_MOVED);
        public static final AccessibilityActionCompat ACTION_SCROLL_FORWARD = new AccessibilityActionCompat((int) RecyclerView.ItemAnimator.FLAG_APPEARED_IN_PRE_LAYOUT);
        public static final AccessibilityActionCompat ACTION_SCROLL_BACKWARD = new AccessibilityActionCompat(8192);
        public static final AccessibilityActionCompat ACTION_COPY = new AccessibilityActionCompat(16384);
        public static final AccessibilityActionCompat ACTION_PASTE = new AccessibilityActionCompat(32768);
        public static final AccessibilityActionCompat ACTION_CUT = new AccessibilityActionCompat(65536);
        public static final AccessibilityActionCompat ACTION_SET_SELECTION = new AccessibilityActionCompat(131072);
        public static final AccessibilityActionCompat ACTION_EXPAND = new AccessibilityActionCompat(262144);
        public static final AccessibilityActionCompat ACTION_COLLAPSE = new AccessibilityActionCompat(524288);
        public static final AccessibilityActionCompat ACTION_DISMISS = new AccessibilityActionCompat(1048576);
        public static final AccessibilityActionCompat ACTION_SET_TEXT = new AccessibilityActionCompat(2097152);
        public static final AccessibilityActionCompat ACTION_SHOW_ON_SCREEN = new AccessibilityActionCompat(AccessibilityNodeInfoCompat.IMPL.getActionShowOnScreen());
        public static final AccessibilityActionCompat ACTION_SCROLL_TO_POSITION = new AccessibilityActionCompat(AccessibilityNodeInfoCompat.IMPL.getActionScrollToPosition());
        public static final AccessibilityActionCompat ACTION_SCROLL_UP = new AccessibilityActionCompat(AccessibilityNodeInfoCompat.IMPL.getActionScrollUp());
        public static final AccessibilityActionCompat ACTION_SCROLL_LEFT = new AccessibilityActionCompat(AccessibilityNodeInfoCompat.IMPL.getActionScrollLeft());
        public static final AccessibilityActionCompat ACTION_SCROLL_DOWN = new AccessibilityActionCompat(AccessibilityNodeInfoCompat.IMPL.getActionScrollDown());
        public static final AccessibilityActionCompat ACTION_SCROLL_RIGHT = new AccessibilityActionCompat(AccessibilityNodeInfoCompat.IMPL.getActionScrollRight());
        public static final AccessibilityActionCompat ACTION_CONTEXT_CLICK = new AccessibilityActionCompat(AccessibilityNodeInfoCompat.IMPL.getActionContextClick());
        public static final AccessibilityActionCompat ACTION_SET_PROGRESS = new AccessibilityActionCompat(AccessibilityNodeInfoCompat.IMPL.getActionSetProgress());

        private AccessibilityActionCompat(int actionId) {
            this(AccessibilityNodeInfoCompat.IMPL.newAccessibilityAction$442b94a0(actionId));
        }

        private AccessibilityActionCompat(Object action) {
            this.mAction = action;
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$CollectionInfoCompat */
    /* loaded from: classes.dex */
    public static class CollectionInfoCompat {
        public final Object mInfo;

        public CollectionInfoCompat(Object info2) {
            this.mInfo = info2;
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$CollectionItemInfoCompat */
    /* loaded from: classes.dex */
    public static class CollectionItemInfoCompat {
        public final Object mInfo;

        public static CollectionItemInfoCompat obtain(int rowIndex, int rowSpan, int columnIndex, int columnSpan, boolean heading, boolean selected) {
            return new CollectionItemInfoCompat(AccessibilityNodeInfoCompat.IMPL.obtainCollectionItemInfo(rowIndex, rowSpan, columnIndex, columnSpan, heading, selected));
        }

        public CollectionItemInfoCompat(Object info2) {
            this.mInfo = info2;
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoStubImpl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoStubImpl implements AccessibilityNodeInfoImpl {
        AccessibilityNodeInfoStubImpl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object newAccessibilityAction$442b94a0(int actionId) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object obtain(Object info2) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void addAction(Object info2, int action) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean removeAction(Object info2, Object action) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void addChild(Object info2, View child) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public int getActions(Object info2) {
            return 0;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void getBoundsInParent(Object info2, Rect outBounds) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void getBoundsInScreen(Object info2, Rect outBounds) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public CharSequence getClassName(Object info2) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public CharSequence getContentDescription(Object info2) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public CharSequence getPackageName(Object info2) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public CharSequence getText(Object info2) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isCheckable(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isChecked(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isClickable(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isEnabled(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isFocusable(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isFocused(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isVisibleToUser(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isAccessibilityFocused(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isLongClickable(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isPassword(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isScrollable(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isSelected(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setMovementGranularities(Object info2, int granularities) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public int getMovementGranularities(Object info2) {
            return 0;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setBoundsInParent(Object info2, Rect bounds) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setBoundsInScreen(Object info2, Rect bounds) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setCheckable(Object info2, boolean checkable) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setChecked(Object info2, boolean checked) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setClassName(Object info2, CharSequence className) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setClickable(Object info2, boolean clickable) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setContentDescription(Object info2, CharSequence contentDescription) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setEnabled(Object info2, boolean enabled) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setFocusable(Object info2, boolean focusable) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setFocused(Object info2, boolean focused) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setVisibleToUser(Object info2, boolean visibleToUser) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setAccessibilityFocused(Object info2, boolean focused) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setLongClickable(Object info2, boolean longClickable) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setPackageName(Object info2, CharSequence packageName) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setParent(Object info2, View parent) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setScrollable(Object info2, boolean scrollable) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setSelected(Object info2, boolean selected) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setSource(Object info2, View source) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setText(Object info2, CharSequence text) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void recycle(Object info2) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public String getViewIdResourceName(Object info2) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setCollectionInfo(Object info2, Object collectionInfo) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object getCollectionItemInfo(Object info2) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setCollectionItemInfo(Object info2, Object collectionItemInfo) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object obtainCollectionInfo(int rowCount, int columnCount, boolean hierarchical, int selectionMode) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object obtainCollectionItemInfo(int rowIndex, int rowSpan, int columnIndex, int columnSpan, boolean heading, boolean selected) {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public int getCollectionItemColumnIndex(Object info2) {
            return 0;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public int getCollectionItemColumnSpan(Object info2) {
            return 0;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public int getCollectionItemRowIndex(Object info2) {
            return 0;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public int getCollectionItemRowSpan(Object info2) {
            return 0;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public boolean isCollectionItemSelected(Object info2) {
            return false;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setContentInvalid$4cfd3ce3(Object info2) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setError(Object info2, CharSequence error) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setLabelFor(Object info2, View labeled) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public void setDismissable(Object info2, boolean dismissable) {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object getActionScrollToPosition() {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object getActionSetProgress() {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object getActionShowOnScreen() {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object getActionScrollUp() {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object getActionScrollDown() {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object getActionScrollLeft() {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object getActionScrollRight() {
            return null;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object getActionContextClick() {
            return null;
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoIcsImpl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoIcsImpl extends AccessibilityNodeInfoStubImpl {
        AccessibilityNodeInfoIcsImpl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object obtain(Object info2) {
            return AccessibilityNodeInfo.obtain((AccessibilityNodeInfo) info2);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void addAction(Object info2, int action) {
            ((AccessibilityNodeInfo) info2).addAction(action);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void addChild(Object info2, View child) {
            ((AccessibilityNodeInfo) info2).addChild(child);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final int getActions(Object info2) {
            return ((AccessibilityNodeInfo) info2).getActions();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void getBoundsInParent(Object info2, Rect outBounds) {
            ((AccessibilityNodeInfo) info2).getBoundsInParent(outBounds);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void getBoundsInScreen(Object info2, Rect outBounds) {
            ((AccessibilityNodeInfo) info2).getBoundsInScreen(outBounds);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final CharSequence getClassName(Object info2) {
            return ((AccessibilityNodeInfo) info2).getClassName();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final CharSequence getContentDescription(Object info2) {
            return ((AccessibilityNodeInfo) info2).getContentDescription();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final CharSequence getPackageName(Object info2) {
            return ((AccessibilityNodeInfo) info2).getPackageName();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final CharSequence getText(Object info2) {
            return ((AccessibilityNodeInfo) info2).getText();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isCheckable(Object info2) {
            return ((AccessibilityNodeInfo) info2).isCheckable();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isChecked(Object info2) {
            return ((AccessibilityNodeInfo) info2).isChecked();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isClickable(Object info2) {
            return ((AccessibilityNodeInfo) info2).isClickable();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isEnabled(Object info2) {
            return ((AccessibilityNodeInfo) info2).isEnabled();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isFocusable(Object info2) {
            return ((AccessibilityNodeInfo) info2).isFocusable();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isFocused(Object info2) {
            return ((AccessibilityNodeInfo) info2).isFocused();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isLongClickable(Object info2) {
            return ((AccessibilityNodeInfo) info2).isLongClickable();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isPassword(Object info2) {
            return ((AccessibilityNodeInfo) info2).isPassword();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isScrollable(Object info2) {
            return ((AccessibilityNodeInfo) info2).isScrollable();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isSelected(Object info2) {
            return ((AccessibilityNodeInfo) info2).isSelected();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setBoundsInParent(Object info2, Rect bounds) {
            ((AccessibilityNodeInfo) info2).setBoundsInParent(bounds);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setBoundsInScreen(Object info2, Rect bounds) {
            ((AccessibilityNodeInfo) info2).setBoundsInScreen(bounds);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setCheckable(Object info2, boolean checkable) {
            ((AccessibilityNodeInfo) info2).setCheckable(checkable);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setChecked(Object info2, boolean checked) {
            ((AccessibilityNodeInfo) info2).setChecked(checked);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setClassName(Object info2, CharSequence className) {
            ((AccessibilityNodeInfo) info2).setClassName(className);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setClickable(Object info2, boolean clickable) {
            ((AccessibilityNodeInfo) info2).setClickable(clickable);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setContentDescription(Object info2, CharSequence contentDescription) {
            ((AccessibilityNodeInfo) info2).setContentDescription(contentDescription);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setEnabled(Object info2, boolean enabled) {
            ((AccessibilityNodeInfo) info2).setEnabled(enabled);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setFocusable(Object info2, boolean focusable) {
            ((AccessibilityNodeInfo) info2).setFocusable(focusable);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setFocused(Object info2, boolean focused) {
            ((AccessibilityNodeInfo) info2).setFocused(focused);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setLongClickable(Object info2, boolean longClickable) {
            ((AccessibilityNodeInfo) info2).setLongClickable(longClickable);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setPackageName(Object info2, CharSequence packageName) {
            ((AccessibilityNodeInfo) info2).setPackageName(packageName);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setParent(Object info2, View parent) {
            ((AccessibilityNodeInfo) info2).setParent(parent);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setScrollable(Object info2, boolean scrollable) {
            ((AccessibilityNodeInfo) info2).setScrollable(scrollable);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setSelected(Object info2, boolean selected) {
            ((AccessibilityNodeInfo) info2).setSelected(selected);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setSource(Object info2, View source) {
            ((AccessibilityNodeInfo) info2).setSource(source);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setText(Object info2, CharSequence text) {
            ((AccessibilityNodeInfo) info2).setText(text);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void recycle(Object info2) {
            ((AccessibilityNodeInfo) info2).recycle();
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanImpl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoJellybeanImpl extends AccessibilityNodeInfoIcsImpl {
        AccessibilityNodeInfoJellybeanImpl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isVisibleToUser(Object info2) {
            return ((AccessibilityNodeInfo) info2).isVisibleToUser();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setVisibleToUser(Object info2, boolean visibleToUser) {
            ((AccessibilityNodeInfo) info2).setVisibleToUser(visibleToUser);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isAccessibilityFocused(Object info2) {
            return ((AccessibilityNodeInfo) info2).isAccessibilityFocused();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setAccessibilityFocused(Object info2, boolean focused) {
            ((AccessibilityNodeInfo) info2).setAccessibilityFocused(focused);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setMovementGranularities(Object info2, int granularities) {
            ((AccessibilityNodeInfo) info2).setMovementGranularities(granularities);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final int getMovementGranularities(Object info2) {
            return ((AccessibilityNodeInfo) info2).getMovementGranularities();
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanMr1Impl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoJellybeanMr1Impl extends AccessibilityNodeInfoJellybeanImpl {
        AccessibilityNodeInfoJellybeanMr1Impl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setLabelFor(Object info2, View labeled) {
            ((AccessibilityNodeInfo) info2).setLabelFor(labeled);
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoJellybeanMr2Impl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoJellybeanMr2Impl extends AccessibilityNodeInfoJellybeanMr1Impl {
        AccessibilityNodeInfoJellybeanMr2Impl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final String getViewIdResourceName(Object info2) {
            return ((AccessibilityNodeInfo) info2).getViewIdResourceName();
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoKitKatImpl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoKitKatImpl extends AccessibilityNodeInfoJellybeanMr2Impl {
        AccessibilityNodeInfoKitKatImpl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setCollectionInfo(Object info2, Object collectionInfo) {
            ((AccessibilityNodeInfo) info2).setCollectionInfo((AccessibilityNodeInfo.CollectionInfo) collectionInfo);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object obtainCollectionInfo(int rowCount, int columnCount, boolean hierarchical, int selectionMode) {
            return AccessibilityNodeInfo.CollectionInfo.obtain(rowCount, columnCount, hierarchical);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public Object obtainCollectionItemInfo(int rowIndex, int rowSpan, int columnIndex, int columnSpan, boolean heading, boolean selected) {
            return AccessibilityNodeInfo.CollectionItemInfo.obtain(rowIndex, rowSpan, columnIndex, columnSpan, heading);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object getCollectionItemInfo(Object info2) {
            return ((AccessibilityNodeInfo) info2).getCollectionItemInfo();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final int getCollectionItemColumnIndex(Object info2) {
            return ((AccessibilityNodeInfo.CollectionItemInfo) info2).getColumnIndex();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final int getCollectionItemColumnSpan(Object info2) {
            return ((AccessibilityNodeInfo.CollectionItemInfo) info2).getColumnSpan();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final int getCollectionItemRowIndex(Object info2) {
            return ((AccessibilityNodeInfo.CollectionItemInfo) info2).getRowIndex();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final int getCollectionItemRowSpan(Object info2) {
            return ((AccessibilityNodeInfo.CollectionItemInfo) info2).getRowSpan();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setCollectionItemInfo(Object info2, Object collectionItemInfo) {
            ((AccessibilityNodeInfo) info2).setCollectionItemInfo((AccessibilityNodeInfo.CollectionItemInfo) collectionItemInfo);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setContentInvalid$4cfd3ce3(Object info2) {
            ((AccessibilityNodeInfo) info2).setContentInvalid(true);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setDismissable(Object info2, boolean dismissable) {
            ((AccessibilityNodeInfo) info2).setDismissable(dismissable);
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoApi21Impl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoApi21Impl extends AccessibilityNodeInfoKitKatImpl {
        AccessibilityNodeInfoApi21Impl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object newAccessibilityAction$442b94a0(int actionId) {
            return new AccessibilityNodeInfo.AccessibilityAction(actionId, null);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoKitKatImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object obtainCollectionInfo(int rowCount, int columnCount, boolean hierarchical, int selectionMode) {
            return AccessibilityNodeInfo.CollectionInfo.obtain(rowCount, columnCount, hierarchical, selectionMode);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean removeAction(Object info2, Object action) {
            return ((AccessibilityNodeInfo) info2).removeAction((AccessibilityNodeInfo.AccessibilityAction) action);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoKitKatImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object obtainCollectionItemInfo(int rowIndex, int rowSpan, int columnIndex, int columnSpan, boolean heading, boolean selected) {
            return AccessibilityNodeInfo.CollectionItemInfo.obtain(rowIndex, rowSpan, columnIndex, columnSpan, heading, selected);
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final boolean isCollectionItemSelected(Object info2) {
            return ((AccessibilityNodeInfo.CollectionItemInfo) info2).isSelected();
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final void setError(Object info2, CharSequence error) {
            ((AccessibilityNodeInfo) info2).setError(error);
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoApi22Impl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoApi22Impl extends AccessibilityNodeInfoApi21Impl {
        AccessibilityNodeInfoApi22Impl() {
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoApi23Impl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoApi23Impl extends AccessibilityNodeInfoApi22Impl {
        AccessibilityNodeInfoApi23Impl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object getActionScrollToPosition() {
            return AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object getActionShowOnScreen() {
            return AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object getActionScrollUp() {
            return AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object getActionScrollDown() {
            return AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object getActionScrollLeft() {
            return AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object getActionScrollRight() {
            return AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT;
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object getActionContextClick() {
            return AccessibilityNodeInfo.AccessibilityAction.ACTION_CONTEXT_CLICK;
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeInfoCompat$AccessibilityNodeInfoApi24Impl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeInfoApi24Impl extends AccessibilityNodeInfoApi23Impl {
        AccessibilityNodeInfoApi24Impl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeInfoCompat.AccessibilityNodeInfoImpl
        public final Object getActionSetProgress() {
            return AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS;
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 24) {
            IMPL = new AccessibilityNodeInfoApi24Impl();
        } else if (Build.VERSION.SDK_INT >= 23) {
            IMPL = new AccessibilityNodeInfoApi23Impl();
        } else if (Build.VERSION.SDK_INT >= 22) {
            IMPL = new AccessibilityNodeInfoApi22Impl();
        } else if (Build.VERSION.SDK_INT >= 21) {
            IMPL = new AccessibilityNodeInfoApi21Impl();
        } else if (Build.VERSION.SDK_INT >= 19) {
            IMPL = new AccessibilityNodeInfoKitKatImpl();
        } else if (Build.VERSION.SDK_INT >= 18) {
            IMPL = new AccessibilityNodeInfoJellybeanMr2Impl();
        } else if (Build.VERSION.SDK_INT >= 17) {
            IMPL = new AccessibilityNodeInfoJellybeanMr1Impl();
        } else if (Build.VERSION.SDK_INT >= 16) {
            IMPL = new AccessibilityNodeInfoJellybeanImpl();
        } else if (Build.VERSION.SDK_INT >= 14) {
            IMPL = new AccessibilityNodeInfoIcsImpl();
        } else {
            IMPL = new AccessibilityNodeInfoStubImpl();
        }
    }

    public AccessibilityNodeInfoCompat(Object info2) {
        this.mInfo = info2;
    }

    public static AccessibilityNodeInfoCompat obtain(AccessibilityNodeInfoCompat info2) {
        Object obtain = IMPL.obtain(info2.mInfo);
        if (obtain != null) {
            return new AccessibilityNodeInfoCompat(obtain);
        }
        return null;
    }

    public final void setSource(View source) {
        IMPL.setSource(this.mInfo, source);
    }

    public final void addChild(View child) {
        IMPL.addChild(this.mInfo, child);
    }

    public final int getActions() {
        return IMPL.getActions(this.mInfo);
    }

    public final void addAction(int action) {
        IMPL.addAction(this.mInfo, action);
    }

    public final boolean removeAction(AccessibilityActionCompat action) {
        return IMPL.removeAction(this.mInfo, action.mAction);
    }

    public final void setParent(View parent) {
        IMPL.setParent(this.mInfo, parent);
    }

    public final void getBoundsInParent(Rect outBounds) {
        IMPL.getBoundsInParent(this.mInfo, outBounds);
    }

    public final void setBoundsInParent(Rect bounds) {
        IMPL.setBoundsInParent(this.mInfo, bounds);
    }

    public final void getBoundsInScreen(Rect outBounds) {
        IMPL.getBoundsInScreen(this.mInfo, outBounds);
    }

    public final void setBoundsInScreen(Rect bounds) {
        IMPL.setBoundsInScreen(this.mInfo, bounds);
    }

    public final void setCheckable(boolean checkable) {
        IMPL.setCheckable(this.mInfo, checkable);
    }

    public final boolean isFocusable() {
        return IMPL.isFocusable(this.mInfo);
    }

    public final void setFocusable(boolean focusable) {
        IMPL.setFocusable(this.mInfo, focusable);
    }

    public final boolean isFocused() {
        return IMPL.isFocused(this.mInfo);
    }

    public final void setFocused(boolean focused) {
        IMPL.setFocused(this.mInfo, focused);
    }

    public final boolean isVisibleToUser() {
        return IMPL.isVisibleToUser(this.mInfo);
    }

    public final void setVisibleToUser(boolean visibleToUser) {
        IMPL.setVisibleToUser(this.mInfo, visibleToUser);
    }

    public final boolean isAccessibilityFocused() {
        return IMPL.isAccessibilityFocused(this.mInfo);
    }

    public final void setAccessibilityFocused(boolean focused) {
        IMPL.setAccessibilityFocused(this.mInfo, focused);
    }

    public final boolean isSelected() {
        return IMPL.isSelected(this.mInfo);
    }

    public final void setSelected(boolean selected) {
        IMPL.setSelected(this.mInfo, selected);
    }

    public final boolean isClickable() {
        return IMPL.isClickable(this.mInfo);
    }

    public final void setClickable(boolean clickable) {
        IMPL.setClickable(this.mInfo, clickable);
    }

    public final boolean isLongClickable() {
        return IMPL.isLongClickable(this.mInfo);
    }

    public final void setLongClickable(boolean longClickable) {
        IMPL.setLongClickable(this.mInfo, longClickable);
    }

    public final boolean isEnabled() {
        return IMPL.isEnabled(this.mInfo);
    }

    public final void setEnabled(boolean enabled) {
        IMPL.setEnabled(this.mInfo, enabled);
    }

    public final void setScrollable(boolean scrollable) {
        IMPL.setScrollable(this.mInfo, scrollable);
    }

    public final CharSequence getPackageName() {
        return IMPL.getPackageName(this.mInfo);
    }

    public final void setPackageName(CharSequence packageName) {
        IMPL.setPackageName(this.mInfo, packageName);
    }

    public final CharSequence getClassName() {
        return IMPL.getClassName(this.mInfo);
    }

    public final void setClassName(CharSequence className) {
        IMPL.setClassName(this.mInfo, className);
    }

    public final CharSequence getContentDescription() {
        return IMPL.getContentDescription(this.mInfo);
    }

    public final void setContentDescription(CharSequence contentDescription) {
        IMPL.setContentDescription(this.mInfo, contentDescription);
    }

    public final void recycle() {
        IMPL.recycle(this.mInfo);
    }

    public final void setCollectionItemInfo(Object collectionItemInfo) {
        IMPL.setCollectionItemInfo(this.mInfo, ((CollectionItemInfoCompat) collectionItemInfo).mInfo);
    }

    public final void setDismissable(boolean dismissable) {
        IMPL.setDismissable(this.mInfo, dismissable);
    }

    public final int hashCode() {
        if (this.mInfo == null) {
            return 0;
        }
        return this.mInfo.hashCode();
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj != null && getClass() == obj.getClass()) {
            AccessibilityNodeInfoCompat other = (AccessibilityNodeInfoCompat) obj;
            return this.mInfo == null ? other.mInfo == null : this.mInfo.equals(other.mInfo);
        }
        return false;
    }

    public final String toString() {
        String str;
        StringBuilder builder = new StringBuilder();
        builder.append(super.toString());
        Rect bounds = new Rect();
        getBoundsInParent(bounds);
        builder.append("; boundsInParent: " + bounds);
        getBoundsInScreen(bounds);
        builder.append("; boundsInScreen: " + bounds);
        builder.append("; packageName: ").append(getPackageName());
        builder.append("; className: ").append(getClassName());
        builder.append("; text: ").append(IMPL.getText(this.mInfo));
        builder.append("; contentDescription: ").append(getContentDescription());
        builder.append("; viewId: ").append(IMPL.getViewIdResourceName(this.mInfo));
        builder.append("; checkable: ").append(IMPL.isCheckable(this.mInfo));
        builder.append("; checked: ").append(IMPL.isChecked(this.mInfo));
        builder.append("; focusable: ").append(isFocusable());
        builder.append("; focused: ").append(isFocused());
        builder.append("; selected: ").append(isSelected());
        builder.append("; clickable: ").append(isClickable());
        builder.append("; longClickable: ").append(isLongClickable());
        builder.append("; enabled: ").append(isEnabled());
        builder.append("; password: ").append(IMPL.isPassword(this.mInfo));
        builder.append("; scrollable: " + IMPL.isScrollable(this.mInfo));
        builder.append("; [");
        int actionBits = getActions();
        while (actionBits != 0) {
            int action = 1 << Integer.numberOfTrailingZeros(actionBits);
            actionBits &= action ^ (-1);
            switch (action) {
                case 1:
                    str = "ACTION_FOCUS";
                    break;
                case 2:
                    str = "ACTION_CLEAR_FOCUS";
                    break;
                case 4:
                    str = "ACTION_SELECT";
                    break;
                case 8:
                    str = "ACTION_CLEAR_SELECTION";
                    break;
                case 16:
                    str = "ACTION_CLICK";
                    break;
                case 32:
                    str = "ACTION_LONG_CLICK";
                    break;
                case 64:
                    str = "ACTION_ACCESSIBILITY_FOCUS";
                    break;
                case NotificationCompat.FLAG_HIGH_PRIORITY /* 128 */:
                    str = "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
                    break;
                case NotificationCompat.FLAG_LOCAL_ONLY /* 256 */:
                    str = "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
                    break;
                case NotificationCompat.FLAG_GROUP_SUMMARY /* 512 */:
                    str = "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
                    break;
                case 1024:
                    str = "ACTION_NEXT_HTML_ELEMENT";
                    break;
                case RecyclerView.ItemAnimator.FLAG_MOVED /* 2048 */:
                    str = "ACTION_PREVIOUS_HTML_ELEMENT";
                    break;
                case RecyclerView.ItemAnimator.FLAG_APPEARED_IN_PRE_LAYOUT /* 4096 */:
                    str = "ACTION_SCROLL_FORWARD";
                    break;
                case 8192:
                    str = "ACTION_SCROLL_BACKWARD";
                    break;
                case 16384:
                    str = "ACTION_COPY";
                    break;
                case 32768:
                    str = "ACTION_PASTE";
                    break;
                case 65536:
                    str = "ACTION_CUT";
                    break;
                case 131072:
                    str = "ACTION_SET_SELECTION";
                    break;
                default:
                    str = "ACTION_UNKNOWN";
                    break;
            }
            builder.append(str);
            if (actionBits != 0) {
                builder.append(", ");
            }
        }
        builder.append("]");
        return builder.toString();
    }
}
