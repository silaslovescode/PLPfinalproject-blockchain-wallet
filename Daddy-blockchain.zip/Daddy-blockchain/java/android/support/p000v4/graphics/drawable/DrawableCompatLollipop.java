package android.support.p000v4.graphics.drawable;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.InsetDrawable;

@TargetApi(21)
/* renamed from: android.support.v4.graphics.drawable.DrawableCompatLollipop */
/* loaded from: classes.dex */
final class DrawableCompatLollipop {
    public static void clearColorFilter(Drawable drawable) {
        DrawableContainer.DrawableContainerState state;
        while (true) {
            drawable.clearColorFilter();
            if (drawable instanceof InsetDrawable) {
                drawable = ((InsetDrawable) drawable).getDrawable();
            } else if (!(drawable instanceof DrawableWrapper)) {
                break;
            } else {
                drawable = ((DrawableWrapper) drawable).getWrappedDrawable();
            }
        }
        if ((drawable instanceof DrawableContainer) && (state = (DrawableContainer.DrawableContainerState) ((DrawableContainer) drawable).getConstantState()) != null) {
            int count = state.getChildCount();
            for (int i = 0; i < count; i++) {
                Drawable child = state.getChild(i);
                if (child != null) {
                    clearColorFilter(child);
                }
            }
        }
    }
}
