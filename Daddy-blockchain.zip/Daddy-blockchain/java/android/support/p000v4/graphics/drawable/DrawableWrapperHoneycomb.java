package android.support.p000v4.graphics.drawable;

import android.annotation.TargetApi;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.p000v4.graphics.drawable.DrawableWrapperGingerbread;

@TargetApi(11)
/* renamed from: android.support.v4.graphics.drawable.DrawableWrapperHoneycomb */
/* loaded from: classes.dex */
class DrawableWrapperHoneycomb extends DrawableWrapperGingerbread {
    /* JADX INFO: Access modifiers changed from: package-private */
    public DrawableWrapperHoneycomb(Drawable drawable) {
        super(drawable);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public DrawableWrapperHoneycomb(DrawableWrapperGingerbread.DrawableWrapperState state, Resources resources) {
        super(state, resources);
    }

    @Override // android.graphics.drawable.Drawable
    public void jumpToCurrentState() {
        this.mDrawable.jumpToCurrentState();
    }

    @Override // android.support.p000v4.graphics.drawable.DrawableWrapperGingerbread
    DrawableWrapperGingerbread.DrawableWrapperState mutateConstantState() {
        return new DrawableWrapperStateHoneycomb(this.mState);
    }

    /* renamed from: android.support.v4.graphics.drawable.DrawableWrapperHoneycomb$DrawableWrapperStateHoneycomb */
    /* loaded from: classes.dex */
    private static class DrawableWrapperStateHoneycomb extends DrawableWrapperGingerbread.DrawableWrapperState {
        DrawableWrapperStateHoneycomb(DrawableWrapperGingerbread.DrawableWrapperState orig) {
            super(orig);
        }

        @Override // android.support.p000v4.graphics.drawable.DrawableWrapperGingerbread.DrawableWrapperState, android.graphics.drawable.Drawable.ConstantState
        public final Drawable newDrawable(Resources res) {
            return new DrawableWrapperHoneycomb(this, res);
        }
    }
}
