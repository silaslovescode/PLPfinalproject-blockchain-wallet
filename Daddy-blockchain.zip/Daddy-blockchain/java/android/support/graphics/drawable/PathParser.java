package android.support.graphics.drawable;

import android.graphics.Path;
import java.util.ArrayList;

/* loaded from: classes.dex */
final class PathParser {
    static float[] copyOfRange$7b60297f(float[] original, int end) {
        if (end < 0) {
            throw new IllegalArgumentException();
        }
        int originalLength = original.length;
        if (originalLength < 0) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int resultLength = end + 0;
        int copyLength = Math.min(resultLength, originalLength + 0);
        float[] result = new float[resultLength];
        System.arraycopy(original, 0, result, 0, copyLength);
        return result;
    }

    public static PathDataNode[] createNodesFromPathData(String pathData) {
        if (pathData == null) {
            return null;
        }
        int start = 0;
        int end = 1;
        ArrayList<PathDataNode> list = new ArrayList<>();
        while (end < pathData.length()) {
            int end2 = nextStart(pathData, end);
            String s = pathData.substring(start, end2).trim();
            if (s.length() > 0) {
                float[] val = getFloats(s);
                addNode(list, s.charAt(0), val);
            }
            start = end2;
            end = end2 + 1;
        }
        if (end - start == 1 && start < pathData.length()) {
            addNode(list, pathData.charAt(start), new float[0]);
        }
        return (PathDataNode[]) list.toArray(new PathDataNode[list.size()]);
    }

    public static PathDataNode[] deepCopyNodes(PathDataNode[] source) {
        if (source == null) {
            return null;
        }
        PathDataNode[] copy = new PathDataNode[source.length];
        for (int i = 0; i < source.length; i++) {
            copy[i] = new PathDataNode(source[i]);
        }
        return copy;
    }

    private static int nextStart(String s, int end) {
        while (end < s.length()) {
            char c = s.charAt(end);
            if (((c - 'A') * (c - 'Z') <= 0 || (c - 'a') * (c - 'z') <= 0) && c != 'e' && c != 'E') {
                break;
            }
            end++;
        }
        return end;
    }

    private static void addNode(ArrayList<PathDataNode> list, char cmd, float[] val) {
        list.add(new PathDataNode(cmd, val));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class ExtractFloatResult {
        int mEndPosition;
        boolean mEndWithNegOrDot;

        ExtractFloatResult() {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x0088 A[Catch: NumberFormatException -> 0x005b, TryCatch #0 {NumberFormatException -> 0x005b, blocks: (B:14:0x001f, B:16:0x0033, B:17:0x003b, B:19:0x0041, B:20:0x0046, B:22:0x004b, B:26:0x0056, B:34:0x007d, B:36:0x0082, B:38:0x0088, B:39:0x0094, B:42:0x009b, B:43:0x009f), top: B:46:0x001f }] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00a5  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x009b A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x0098 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static float[] getFloats(java.lang.String r14) {
        /*
            r8 = 0
            char r8 = r14.charAt(r8)
            r9 = 122(0x7a, float:1.71E-43)
            if (r8 != r9) goto L1b
            r8 = 1
        La:
            r9 = 0
            char r9 = r14.charAt(r9)
            r10 = 90
            if (r9 != r10) goto L1d
            r9 = 1
        L14:
            r8 = r8 | r9
            if (r8 == 0) goto L1f
            r8 = 0
            float[] r8 = new float[r8]
        L1a:
            return r8
        L1b:
            r8 = 0
            goto La
        L1d:
            r9 = 0
            goto L14
        L1f:
            int r8 = r14.length()     // Catch: java.lang.NumberFormatException -> L5b
            float[] r5 = new float[r8]     // Catch: java.lang.NumberFormatException -> L5b
            r0 = 0
            r6 = 1
            android.support.graphics.drawable.PathParser$ExtractFloatResult r4 = new android.support.graphics.drawable.PathParser$ExtractFloatResult     // Catch: java.lang.NumberFormatException -> L5b
            r4.<init>()     // Catch: java.lang.NumberFormatException -> L5b
            int r7 = r14.length()     // Catch: java.lang.NumberFormatException -> L5b
            r1 = r0
        L31:
            if (r6 >= r7) goto L9f
            r10 = 0
            r8 = 0
            r4.mEndWithNegOrDot = r8     // Catch: java.lang.NumberFormatException -> L5b
            r9 = 0
            r8 = 0
            r11 = r8
            r12 = r6
        L3b:
            int r8 = r14.length()     // Catch: java.lang.NumberFormatException -> L5b
            if (r12 >= r8) goto L82
            r8 = 0
            char r13 = r14.charAt(r12)     // Catch: java.lang.NumberFormatException -> L5b
            switch(r13) {
                case 32: goto L50;
                case 44: goto L50;
                case 45: goto L52;
                case 46: goto L77;
                case 69: goto L80;
                case 101: goto L80;
                default: goto L49;
            }     // Catch: java.lang.NumberFormatException -> L5b
        L49:
            if (r10 != 0) goto L82
            int r11 = r12 + 1
            r12 = r11
            r11 = r8
            goto L3b
        L50:
            r10 = 1
            goto L49
        L52:
            if (r12 == r6) goto L49
            if (r11 != 0) goto L49
            r10 = 1
            r11 = 1
            r4.mEndWithNegOrDot = r11     // Catch: java.lang.NumberFormatException -> L5b
            goto L49
        L5b:
            r2 = move-exception
            java.lang.RuntimeException r8 = new java.lang.RuntimeException
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            java.lang.String r10 = "error in parsing \""
            r9.<init>(r10)
            java.lang.StringBuilder r9 = r9.append(r14)
            java.lang.String r10 = "\""
            java.lang.StringBuilder r9 = r9.append(r10)
            java.lang.String r9 = r9.toString()
            r8.<init>(r9, r2)
            throw r8
        L77:
            if (r9 != 0) goto L7b
            r9 = 1
            goto L49
        L7b:
            r10 = 1
            r11 = 1
            r4.mEndWithNegOrDot = r11     // Catch: java.lang.NumberFormatException -> L5b
            goto L49
        L80:
            r8 = 1
            goto L49
        L82:
            r4.mEndPosition = r12     // Catch: java.lang.NumberFormatException -> L5b
            int r3 = r4.mEndPosition     // Catch: java.lang.NumberFormatException -> L5b
            if (r6 >= r3) goto La5
            int r0 = r1 + 1
            java.lang.String r8 = r14.substring(r6, r3)     // Catch: java.lang.NumberFormatException -> L5b
            float r8 = java.lang.Float.parseFloat(r8)     // Catch: java.lang.NumberFormatException -> L5b
            r5[r1] = r8     // Catch: java.lang.NumberFormatException -> L5b
        L94:
            boolean r8 = r4.mEndWithNegOrDot     // Catch: java.lang.NumberFormatException -> L5b
            if (r8 == 0) goto L9b
            r6 = r3
            r1 = r0
            goto L31
        L9b:
            int r6 = r3 + 1
            r1 = r0
            goto L31
        L9f:
            float[] r8 = copyOfRange$7b60297f(r5, r1)     // Catch: java.lang.NumberFormatException -> L5b
            goto L1a
        La5:
            r0 = r1
            goto L94
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.graphics.drawable.PathParser.getFloats(java.lang.String):float[]");
    }

    /* loaded from: classes.dex */
    public static class PathDataNode {
        float[] params;
        char type;

        PathDataNode(char type, float[] params) {
            this.type = type;
            this.params = params;
        }

        PathDataNode(PathDataNode n) {
            this.type = n.type;
            this.params = PathParser.copyOfRange$7b60297f(n.params, n.params.length);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        public static void drawArc(Path p, float x0, float y0, float x1, float y1, float a, float b, float theta, boolean isMoreThanHalf, boolean isPositiveArc) {
            double cx;
            double cy;
            while (true) {
                double thetaD = Math.toRadians(theta);
                double cosTheta = Math.cos(thetaD);
                double sinTheta = Math.sin(thetaD);
                double x0p = ((x0 * cosTheta) + (y0 * sinTheta)) / a;
                double y0p = (((-x0) * sinTheta) + (y0 * cosTheta)) / b;
                double x1p = ((x1 * cosTheta) + (y1 * sinTheta)) / a;
                double y1p = (((-x1) * sinTheta) + (y1 * cosTheta)) / b;
                double dx = x0p - x1p;
                double dy = y0p - y1p;
                double xm = (x0p + x1p) / 2.0d;
                double ym = (y0p + y1p) / 2.0d;
                double dsq = (dx * dx) + (dy * dy);
                if (dsq != 0.0d) {
                    double disc = (1.0d / dsq) - 0.25d;
                    if (disc < 0.0d) {
                        float adjust = (float) (Math.sqrt(dsq) / 1.99999d);
                        a *= adjust;
                        b *= adjust;
                    } else {
                        double s = Math.sqrt(disc);
                        double sdx = s * dx;
                        double sdy = s * dy;
                        if (isMoreThanHalf == isPositiveArc) {
                            cx = xm - sdy;
                            cy = ym + sdx;
                        } else {
                            cx = xm + sdy;
                            cy = ym - sdx;
                        }
                        double eta0 = Math.atan2(y0p - cy, x0p - cx);
                        double sweep = Math.atan2(y1p - cy, x1p - cx) - eta0;
                        if (isPositiveArc != (sweep >= 0.0d)) {
                            if (sweep > 0.0d) {
                                sweep -= 6.283185307179586d;
                            } else {
                                sweep += 6.283185307179586d;
                            }
                        }
                        double cx2 = cx * a;
                        double cy2 = cy * b;
                        double cx3 = (cx2 * cosTheta) - (cy2 * sinTheta);
                        double cy3 = (cx2 * sinTheta) + (cy2 * cosTheta);
                        double d = a;
                        double d2 = b;
                        int ceil = (int) Math.ceil(Math.abs((4.0d * sweep) / 3.141592653589793d));
                        double cos = Math.cos(thetaD);
                        double sin = Math.sin(thetaD);
                        double cos2 = Math.cos(eta0);
                        double sin2 = Math.sin(eta0);
                        double d3 = (((-d) * cos) * sin2) - ((d2 * sin) * cos2);
                        double d4 = sweep / ceil;
                        double d5 = y0;
                        double d6 = x0;
                        int i = 0;
                        double d7 = (sin2 * (-d) * sin) + (cos2 * d2 * cos);
                        double d8 = d3;
                        while (i < ceil) {
                            double d9 = eta0 + d4;
                            double sin3 = Math.sin(d9);
                            double cos3 = Math.cos(d9);
                            double d10 = (((d * cos) * cos3) + cx3) - ((d2 * sin) * sin3);
                            double d11 = (d2 * cos * sin3) + (d * sin * cos3) + cy3;
                            double d12 = (((-d) * cos) * sin3) - ((d2 * sin) * cos3);
                            double d13 = (cos3 * d2 * cos) + (sin3 * (-d) * sin);
                            double tan = Math.tan((d9 - eta0) / 2.0d);
                            double sqrt = ((Math.sqrt((tan * (3.0d * tan)) + 4.0d) - 1.0d) * Math.sin(d9 - eta0)) / 3.0d;
                            p.rCubicTo(((float) ((d8 * sqrt) + d6)) - ((float) d6), ((float) (d5 + (d7 * sqrt))) - ((float) d5), ((float) (d10 - (sqrt * d12))) - ((float) d6), ((float) (d11 - (sqrt * d13))) - ((float) d5), ((float) d10) - ((float) d6), ((float) d11) - ((float) d5));
                            i++;
                            d8 = d12;
                            eta0 = d9;
                            d5 = d11;
                            d6 = d10;
                            d7 = d13;
                        }
                        return;
                    }
                } else {
                    return;
                }
            }
        }
    }
}
