package android.support.design.internal;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.p000v4.p001os.ParcelableCompat;
import android.support.p000v4.p001os.ParcelableCompatCreatorCallbacks;
import android.util.SparseArray;

/* loaded from: classes.dex */
public final class ParcelableSparseArray extends SparseArray<Parcelable> implements Parcelable {
    public static final Parcelable.Creator<ParcelableSparseArray> CREATOR = ParcelableCompat.newCreator(new ParcelableCompatCreatorCallbacks<ParcelableSparseArray>() { // from class: android.support.design.internal.ParcelableSparseArray.1
        @Override // android.support.p000v4.p001os.ParcelableCompatCreatorCallbacks
        /* renamed from: newArray */
        public final /* bridge */ /* synthetic */ ParcelableSparseArray[] mo95newArray(int i) {
            return new ParcelableSparseArray[i];
        }

        @Override // android.support.p000v4.p001os.ParcelableCompatCreatorCallbacks
        /* renamed from: createFromParcel */
        public final /* bridge */ /* synthetic */ ParcelableSparseArray mo94createFromParcel(Parcel parcel, ClassLoader classLoader) {
            return new ParcelableSparseArray(parcel, classLoader);
        }
    });

    public ParcelableSparseArray() {
    }

    public ParcelableSparseArray(Parcel source, ClassLoader loader) {
        int size = source.readInt();
        int[] keys = new int[size];
        source.readIntArray(keys);
        Parcelable[] values = source.readParcelableArray(loader);
        for (int i = 0; i < size; i++) {
            put(keys[i], values[i]);
        }
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int flags) {
        int size = size();
        int[] keys = new int[size];
        Parcelable[] values = new Parcelable[size];
        for (int i = 0; i < size; i++) {
            keys[i] = keyAt(i);
            values[i] = valueAt(i);
        }
        parcel.writeInt(size);
        parcel.writeIntArray(keys);
        parcel.writeParcelableArray(values, flags);
    }
}
