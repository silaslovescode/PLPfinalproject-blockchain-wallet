package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.support.design.widget.ValueAnimatorCompat;
import android.view.animation.Interpolator;

@TargetApi(12)
/* loaded from: classes.dex */
final class ValueAnimatorCompatImplHoneycombMr1 extends ValueAnimatorCompat.Impl {
    private final ValueAnimator mValueAnimator = new ValueAnimator();

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final void start() {
        this.mValueAnimator.start();
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final boolean isRunning() {
        return this.mValueAnimator.isRunning();
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final void setInterpolator(Interpolator interpolator) {
        this.mValueAnimator.setInterpolator(interpolator);
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final void addUpdateListener(final ValueAnimatorCompat.Impl.AnimatorUpdateListenerProxy updateListener) {
        this.mValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: android.support.design.widget.ValueAnimatorCompatImplHoneycombMr1.1
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                updateListener.onAnimationUpdate();
            }
        });
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final void addListener(final ValueAnimatorCompat.Impl.AnimatorListenerProxy listener) {
        this.mValueAnimator.addListener(new AnimatorListenerAdapter() { // from class: android.support.design.widget.ValueAnimatorCompatImplHoneycombMr1.2
            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public final void onAnimationStart(Animator animator) {
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public final void onAnimationEnd(Animator animator) {
                listener.onAnimationEnd();
            }

            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public final void onAnimationCancel(Animator animator) {
            }
        });
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final void setIntValues(int from, int to) {
        this.mValueAnimator.setIntValues(from, to);
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final int getAnimatedIntValue() {
        return ((Integer) this.mValueAnimator.getAnimatedValue()).intValue();
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final void setFloatValues(float from, float to) {
        this.mValueAnimator.setFloatValues(from, to);
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final float getAnimatedFloatValue() {
        return ((Float) this.mValueAnimator.getAnimatedValue()).floatValue();
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final void setDuration(long duration) {
        this.mValueAnimator.setDuration(duration);
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final void cancel() {
        this.mValueAnimator.cancel();
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final float getAnimatedFraction() {
        return this.mValueAnimator.getAnimatedFraction();
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final void end() {
        this.mValueAnimator.end();
    }

    @Override // android.support.design.widget.ValueAnimatorCompat.Impl
    public final long getDuration() {
        return this.mValueAnimator.getDuration();
    }
}
