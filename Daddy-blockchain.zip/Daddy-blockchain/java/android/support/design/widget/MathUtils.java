package android.support.design.widget;

/* loaded from: classes.dex */
final class MathUtils {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static int constrain(int amount, int low, int high) {
        return amount < low ? low : amount > high ? high : amount;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static float constrain$483d241b(float amount) {
        if (amount < 0.0f) {
            return 0.0f;
        }
        if (amount <= 1.0f) {
            return amount;
        }
        return 1.0f;
    }
}
