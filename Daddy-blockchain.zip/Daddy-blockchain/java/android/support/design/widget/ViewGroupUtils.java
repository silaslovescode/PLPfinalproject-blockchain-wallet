package android.support.design.widget;

import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;

/* loaded from: classes.dex */
final class ViewGroupUtils {
    private static final ViewGroupUtilsImpl IMPL;

    /* loaded from: classes.dex */
    private interface ViewGroupUtilsImpl {
        void offsetDescendantRect(ViewGroup viewGroup, View view, Rect rect);
    }

    /* loaded from: classes.dex */
    private static class ViewGroupUtilsImplBase implements ViewGroupUtilsImpl {
        ViewGroupUtilsImplBase() {
        }

        @Override // android.support.design.widget.ViewGroupUtils.ViewGroupUtilsImpl
        public final void offsetDescendantRect(ViewGroup parent, View child, Rect rect) {
            parent.offsetDescendantRectToMyCoords(child, rect);
            rect.offset(child.getScrollX(), child.getScrollY());
        }
    }

    /* loaded from: classes.dex */
    private static class ViewGroupUtilsImplHoneycomb implements ViewGroupUtilsImpl {
        ViewGroupUtilsImplHoneycomb() {
        }

        @Override // android.support.design.widget.ViewGroupUtils.ViewGroupUtilsImpl
        public final void offsetDescendantRect(ViewGroup parent, View child, Rect rect) {
            ViewGroupUtilsHoneycomb.offsetDescendantRect(parent, child, rect);
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 11) {
            IMPL = new ViewGroupUtilsImplHoneycomb();
        } else {
            IMPL = new ViewGroupUtilsImplBase();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static void getDescendantRect(ViewGroup parent, View descendant, Rect out) {
        out.set(0, 0, descendant.getWidth(), descendant.getHeight());
        IMPL.offsetDescendantRect(parent, descendant, out);
    }
}
