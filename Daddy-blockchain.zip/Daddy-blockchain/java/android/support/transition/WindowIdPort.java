package android.support.transition;

import android.annotation.TargetApi;
import android.os.IBinder;
import android.view.View;

@TargetApi(14)
/* loaded from: classes.dex */
final class WindowIdPort {
    private final IBinder mToken;

    private WindowIdPort(IBinder token) {
        this.mToken = token;
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static WindowIdPort getWindowId(View view) {
        return new WindowIdPort(view.getWindowToken());
    }

    public final boolean equals(Object obj) {
        return (obj instanceof WindowIdPort) && ((WindowIdPort) obj).mToken.equals(this.mToken);
    }
}
