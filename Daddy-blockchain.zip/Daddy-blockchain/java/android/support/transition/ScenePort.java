package android.support.transition;

import android.annotation.TargetApi;
import android.view.View;
import android.view.ViewGroup;

@TargetApi(14)
/* loaded from: classes.dex */
final class ScenePort {
    Runnable mExitAction;
    ViewGroup mSceneRoot;

    /* JADX INFO: Access modifiers changed from: package-private */
    public static ScenePort getCurrentScene(View view) {
        return (ScenePort) view.getTag(R.id.transition_current_scene);
    }
}
