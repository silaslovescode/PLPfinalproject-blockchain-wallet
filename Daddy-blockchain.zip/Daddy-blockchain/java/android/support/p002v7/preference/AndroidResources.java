package android.support.p002v7.preference;

/* renamed from: android.support.v7.preference.AndroidResources */
/* loaded from: classes.dex */
public class AndroidResources {
    public static final int ANDROID_R_EDITTEXT_PREFERENCE_STYLE = 16842898;
    public static final int ANDROID_R_ICON_FRAME = 16908350;
    public static final int ANDROID_R_LIST_CONTAINER = 16908351;
    public static final int ANDROID_R_PREFERENCE_FRAGMENT_STYLE = 16844038;
    public static final int ANDROID_R_SWITCH_WIDGET = 16908352;
}
